#include "engine.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#pragma pack(push,1)
typedef struct { uint16_t tex,sx,sy,sw,sh; uint8_t fl,pad; float x,y; uint8_t c[4]; int16_t z,pad2; } Tile;
typedef struct { uint16_t tex,sx,sy,sw,sh; uint8_t fl,pad; float m[6]; float ox,oy; uint8_t c[4]; int16_t z,owner; } Spr;
typedef struct { uint8_t kind,pad; int16_t owner; float m[6]; float hx,hy; } Col;
typedef struct { uint16_t model; int16_t z; float m[6]; float hp,speed,dmg,sight; } EntRec;
typedef struct { char name[24]; uint32_t fs,ns,fc,nc; float rad; } ModelRec;
#pragma pack(pop)

#define TICK (1.0f/60.0f)
#define VS0 0.5f                // world -> screen scale (Godot camera zoom is 2)
#define VSI 0.4f                // zoomed out while the inventory is open so the whole panel fits
#define UPPER 51.584f           // upper arm length (Player.tscn)
#define LOWER 75.2281f          // forearm length
#define ARM_LEN (UPPER+LOWER)
#define MINHAND 30.0f           // min_hand_dist
#define PLAYER_R 37.4672f       // CircleShape2D radius from Player.tscn
#define TOUCH_K 1.8f            // world px per touchpad px
#define MAX_DRAG 20.0f          // max_move_dist_per_frame
#define DRUM 6

enum { K_NONE, K_PLAYER, K_ZOMBIE, K_RAT, K_MONKEY, K_ENEMY_STATIC, K_BULLETS, K_HEALTH, K_GUN, K_EXIT, K_DOOR, K_OTHER };

typedef struct {
    int kind, model, z;
    float x, y, rot, sx, sy;     // placement
    float hp, speed, dmg, sight;
    float r;
    int alive, aware, cooldown, windup, stun, taken, open_t;
    float open;                  // doors: 0 closed .. 1 open
    char name[24];
} Ent;

typedef struct { int16_t z; uint8_t type; uint32_t idx; } DItem;

static struct {
    Tile *tiles; int ntile;
    Spr *spr; int nspr;
    Col *col; int ncol;
    Ent *ent; int nent;
    ModelRec *model; int nmodel;
    Spr *mspr; int nmspr;
    Col *mcol; int nmcol;
    DItem *draw; int ndraw;
    uint16_t *used; int nused;
    // solid grid hash
    int32_t *hkx,*hky; uint8_t *hocc; int hsize;
    int cellsz;
} L;

static char level_names[64][64]; static char level_music[64][32]; static int nlevels; static int cur_level=-1; static char cur_music[32]; static int sfx_n=0;
static struct { uint16_t w,h,tw,th; } texinfo[4096]; static int ntex;
static uint8_t tex_loaded[4096];

/* player */
static struct {
    float x,y, hx,hy;                // hx,hy = hand offset from body (world)
    float gx,gy;                      // grabbed hand world pos while dragging
    int dragging, hp, has_gun, gun_out, dead_t, hurt;
    float face; float slide_x,slide_y; float mv[10][2]; int nmv;
    int ent;
    /* revolver + inventory (same rules as the original) */
    int ammo, syr, slots[6], ready;   /* ammo carried (max 6), syringes carried (max 3), chamber: 0 empty 1 loaded 2 spent shell */
    float rot;                        /* chamber rotation (rad) */
    int inv; float curx,cury; int grab; /* grab: 0 none, 1 bullet, 2 shell, 3 syringe */
} P;

static float cam_x,cam_y; static float g_vs=VS0;
static void mmul(const float*p,const float*q,float*o);
static int in_menu=1,menu_sel=0,menu_top=0; static char disp[64][40];
static struct { float x0,y0,x1,y1; int t; } tracer;
static float frame_t=0;
static float acc=0;

static int morton(int x,int y){int m=0;for(int b=0;b<3;b++)m|=((x>>b)&1)<<(2*b)|((y>>b)&1)<<(2*b+1);return m;}
#define VIG_N 64
static void make_vignette(void){
    static uint16_t d[VIG_N*VIG_N];
    for(int y=0;y<VIG_N;y++)for(int x=0;x<VIG_N;x++){
        float dx=(x+0.5f)/(VIG_N/2)-1.f,dy=(y+0.5f)/(VIG_N/2)-1.f,r=sqrtf(dx*dx+dy*dy);
        float t=(r-0.30f)/0.70f; if(t<0)t=0; if(t>1)t=1; t=t*t*(3-2*t);
        int a=(int)(t*15.f+0.5f); int yy=VIG_N-1-y; d[((yy/8)*(VIG_N/8)+(x/8))*64+morton(x&7,yy&7)]=(uint16_t)a; }
    plat_tex_create(VIG_ID,VIG_N,VIG_N,VIG_N,VIG_N,d);
}
static const char FONT_CHARS[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-:./>";
static const unsigned char FONT_ROWS[][7]={
{0x0E,0x11,0x11,0x1F,0x11,0x11,0x11},
{0x1E,0x11,0x11,0x1E,0x11,0x11,0x1E},
{0x0E,0x11,0x10,0x10,0x10,0x11,0x0E},
{0x1E,0x11,0x11,0x11,0x11,0x11,0x1E},
{0x1F,0x10,0x10,0x1E,0x10,0x10,0x1F},
{0x1F,0x10,0x10,0x1E,0x10,0x10,0x10},
{0x0E,0x11,0x10,0x17,0x11,0x11,0x0F},
{0x11,0x11,0x11,0x1F,0x11,0x11,0x11},
{0x0E,0x04,0x04,0x04,0x04,0x04,0x0E},
{0x07,0x02,0x02,0x02,0x02,0x12,0x0C},
{0x11,0x12,0x14,0x18,0x14,0x12,0x11},
{0x10,0x10,0x10,0x10,0x10,0x10,0x1F},
{0x11,0x1B,0x15,0x15,0x11,0x11,0x11},
{0x11,0x19,0x15,0x13,0x11,0x11,0x11},
{0x0E,0x11,0x11,0x11,0x11,0x11,0x0E},
{0x1E,0x11,0x11,0x1E,0x10,0x10,0x10},
{0x0E,0x11,0x11,0x11,0x15,0x12,0x0D},
{0x1E,0x11,0x11,0x1E,0x14,0x12,0x11},
{0x0F,0x10,0x10,0x0E,0x01,0x01,0x1E},
{0x1F,0x04,0x04,0x04,0x04,0x04,0x04},
{0x11,0x11,0x11,0x11,0x11,0x11,0x0E},
{0x11,0x11,0x11,0x11,0x11,0x0A,0x04},
{0x11,0x11,0x11,0x15,0x15,0x1B,0x11},
{0x11,0x11,0x0A,0x04,0x0A,0x11,0x11},
{0x11,0x11,0x0A,0x04,0x04,0x04,0x04},
{0x1F,0x01,0x02,0x04,0x08,0x10,0x1F},
{0x0E,0x11,0x13,0x15,0x19,0x11,0x0E},
{0x04,0x0C,0x04,0x04,0x04,0x04,0x0E},
{0x0E,0x11,0x01,0x02,0x04,0x08,0x1F},
{0x1E,0x01,0x01,0x0E,0x01,0x01,0x1E},
{0x02,0x06,0x0A,0x12,0x1F,0x02,0x02},
{0x1F,0x10,0x1E,0x01,0x01,0x11,0x0E},
{0x06,0x08,0x10,0x1E,0x11,0x11,0x0E},
{0x1F,0x01,0x02,0x04,0x08,0x08,0x08},
{0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E},
{0x0E,0x11,0x11,0x0F,0x01,0x02,0x0C},
{0x00,0x00,0x00,0x1F,0x00,0x00,0x00},
{0x00,0x04,0x00,0x00,0x00,0x04,0x00},
{0x00,0x00,0x00,0x00,0x00,0x0C,0x0C},
{0x01,0x02,0x02,0x04,0x08,0x08,0x10},
{0x10,0x08,0x04,0x02,0x04,0x08,0x10}};
static void make_font(void){
    static uint16_t d[64*64]; memset(d,0,sizeof d);
    for(int i=0;i<(int)sizeof(FONT_CHARS)-1;i++){ int gx=(i%8)*8,gy=(i/8)*8;
        for(int r=0;r<7;r++)for(int c=0;c<5;c++) if(FONT_ROWS[i][r]&(0x10>>c)){ int x=gx+c,y=gy+r,yy=63-y; d[((yy/8)*8+(x/8))*64+morton(x&7,yy&7)]=0xFFFF; } }
    plat_tex_create(FONT_ID,64,64,64,64,d);
}
static float clampf(float v,float a,float b){return v<a?a:(v>b?b:v);}
static uint8_t *readf(const char *rel,size_t *sz){ char p[256]; snprintf(p,sizeof p,"%s",rel); return plat_read_file(p,sz); }
static uint8_t tex_pin[4096];
static void ensure_tex(int id){
    if(id<0||id>=4096||tex_loaded[id])return;
    char tp[64]; snprintf(tp,sizeof tp,"romfs:/tex/%04d.bin",id); size_t ts; uint8_t*d=readf(tp,&ts); if(!d)return;
    plat_tex_create(id,texinfo[id].w,texinfo[id].h,texinfo[id].tw,texinfo[id].th,d); free(d); tex_loaded[id]=1;
}
/* ---- inventory screen layout, read from romfs:/ui.txt (made from the original Player.tscn) ---- */
typedef struct { int tex,sx,sy,sw,sh; float ox,oy,m[6]; uint8_t c[4]; } USpr;
static struct { USpr chamber,slotReady,slotFired,handle,nextSprite,bulletIdle,bulletHeld,shellIdle,shellHeld,equipIcon,syrTop,syrBase,parasite,parasiteBack,legs,brainBack,brain;
    float pivot[6],next[6],ammoTf[6],dropTf[6],syrTf[6],parasiteHit[6],holster[6]; float slots[6][2]; float slotR,pStartY,pEndY; int ok; } UI;
static void load_ui(void){
    size_t sz; uint8_t*b=readf("romfs:/ui.txt",&sz); if(!b)return;
    char*p=(char*)b,*end=p+sz; char ln[400];
    while(p<end){ char*nl=memchr(p,'\n',end-p); size_t n=nl?(size_t)(nl-p):(size_t)(end-p); if(n>=sizeof ln)n=sizeof ln-1; memcpy(ln,p,n); ln[n]=0; p=nl?nl+1:end;
        char name[40]; 
        if(ln[0]=='S'){ USpr t; int c[4]; memset(&t,0,sizeof t);
            if(sscanf(ln+2,"%39s %d %d %d %d %d %f %f %f %f %f %f %f %f %d %d %d %d",name,&t.tex,&t.sx,&t.sy,&t.sw,&t.sh,&t.ox,&t.oy,&t.m[0],&t.m[1],&t.m[2],&t.m[3],&t.m[4],&t.m[5],&c[0],&c[1],&c[2],&c[3])==18){
                for(int i=0;i<4;i++)t.c[i]=(uint8_t)c[i];
                #define US(n) if(!strcmp(name,#n))UI.n=t;
                US(chamber)US(slotReady)US(slotFired)US(handle)US(nextSprite)US(bulletIdle)US(bulletHeld)US(shellIdle)US(shellHeld)US(equipIcon)US(syrTop)US(syrBase)US(parasite)US(parasiteBack)US(legs)US(brainBack)US(brain)
                #undef US
            }
        } else if(ln[0]=='M'){ float m[6]; if(sscanf(ln+2,"%39s %f %f %f %f %f %f",name,&m[0],&m[1],&m[2],&m[3],&m[4],&m[5])==7){
                #define UM(n) if(!strcmp(name,#n))memcpy(UI.n,m,sizeof m);
                UM(pivot)UM(next)UM(ammoTf)UM(dropTf)UM(syrTf)UM(parasiteHit)UM(holster)
                #undef UM
            }
        } else if(ln[0]=='P'){ int i; float x,y; if(sscanf(ln+2,"%d %f %f",&i,&x,&y)==3&&i>=0&&i<6){UI.slots[i][0]=x;UI.slots[i][1]=y;} }
        else if(ln[0]=='F'){ float v; if(sscanf(ln+2,"%39s %f",name,&v)==2){ if(!strcmp(name,"slotR"))UI.slotR=v; else if(!strcmp(name,"parasiteStartY"))UI.pStartY=v; else if(!strcmp(name,"parasiteEndY"))UI.pEndY=v; } }
    }
    free(b);
    USpr*all[]={&UI.chamber,&UI.slotReady,&UI.slotFired,&UI.handle,&UI.nextSprite,&UI.bulletIdle,&UI.bulletHeld,&UI.shellIdle,&UI.shellHeld,&UI.equipIcon,&UI.syrTop,&UI.syrBase,&UI.parasite,&UI.parasiteBack,&UI.legs,&UI.brainBack,&UI.brain};
    for(size_t i=0;i<sizeof all/sizeof all[0];i++){ int t=all[i]->tex; if(t>=0&&t<4096){tex_pin[t]=1; ensure_tex(t);} }
    UI.ok=UI.slotR>0;
}

/* ---------------- level data ---------------- */
static void free_level(void){
    for(int i=0;i<L.nused;i++) if(!tex_pin[L.used[i]]&&tex_loaded[L.used[i]]){plat_tex_free(L.used[i]);tex_loaded[L.used[i]]=0;}
    free(L.tiles);free(L.spr);free(L.col);free(L.ent);free(L.model);free(L.mspr);free(L.mcol);free(L.draw);free(L.used);
    free(L.hkx);free(L.hky);free(L.hocc);
    memset(&L,0,sizeof L);
}
static uint32_t hashxy(int x,int y){ return ((uint32_t)x*73856093u) ^ ((uint32_t)y*19349663u); }
static void hset(int cx,int cy){
    uint32_t h=hashxy(cx,cy)%L.hsize;
    while(L.hocc[h]){ if(L.hkx[h]==cx&&L.hky[h]==cy)return; h=(h+1)%L.hsize; }
    L.hocc[h]=1;L.hkx[h]=cx;L.hky[h]=cy;
}
static int hget(int cx,int cy){
    uint32_t h=hashxy(cx,cy)%L.hsize;
    while(L.hocc[h]){ if(L.hkx[h]==cx&&L.hky[h]==cy)return 1; h=(h+1)%L.hsize; }
    return 0;
}
static int cmp_draw(const void*a,const void*b){
    const DItem*p=a,*q=b;
    if(p->z!=q->z)return p->z<q->z?-1:1;
    if(p->type!=q->type)return p->type<q->type?-1:1;
    return p->idx<q->idx?-1:(p->idx>q->idx);
}
static int kind_of(const char*n){
    if(!strcmp(n,"Player"))return K_PLAYER;
    if(!strcmp(n,"Zombie"))return K_ZOMBIE;
    if(!strcmp(n,"Rat"))return K_RAT;
    if(!strcmp(n,"Monkey"))return K_MONKEY;
    if(!strcmp(n,"RevolverBullets"))return K_BULLETS;
    if(!strcmp(n,"HealthPickup"))return K_HEALTH;
    if(!strcmp(n,"RevolverPickup"))return K_GUN;
    if(!strcmp(n,"LevelExit"))return K_EXIT;
    size_t l=strlen(n); if(l>=4&&!strcmp(n+l-4,"Door"))return K_DOOR;
    return K_OTHER;
}

int engine_init(void){
    size_t sz; uint8_t *b=readf("romfs:/levels.txt",&sz);
    if(!b)return -1;
    nlevels=0; char *s=(char*)b; char *end=s+sz; char *line=s;
    while(line<end&&nlevels<64){ char *nl=memchr(line,'\n',end-line); size_t n=nl?(size_t)(nl-line):(size_t)(end-line);
        if(n>0&&n<95){ char tmp[96]; memcpy(tmp,line,n); tmp[n]=0; char*bar=strchr(tmp,'|'); if(bar){*bar=0; snprintf(level_music[nlevels],32,"%s",bar+1);} else level_music[nlevels][0]=0; snprintf(level_names[nlevels],64,"%s",tmp); nlevels++; }
        if(!nl)break; line=nl+1; }
    free(b);
    b=readf("romfs:/tex.tbl",&sz); if(!b)return -2;
    uint32_t n; memcpy(&n,b,4); ntex=n>4096?4096:n;
    for(int i=0;i<ntex;i++) memcpy(&texinfo[i],b+4+i*8,8);
    free(b);
    make_vignette(); make_font();
    tex_pin[0]=1; ensure_tex(0); load_ui();
    for(int i=0;i<nlevels;i++){ char*o=disp[i]; o+=sprintf(o,"%02d ",i+1); const char*s=level_names[i]; for(int k=0;s[k]&&o-disp[i]<38;k++){ char ch=s[k]; if(k>0&&ch>='A'&&ch<='Z'&&((s[k-1]>='a'&&s[k-1]<='z')||(s[k-1]>='A'&&s[k-1]<='Z'&&s[k+1]>='a'&&s[k+1]<='z')))*o++=' '; if(ch>='a'&&ch<='z')ch-=32; *o++=ch; } *o=0; }
    in_menu=1; menu_sel=0; plat_music("labs_track");
    return 0;
}
int engine_level_count(void){return nlevels;}

int engine_load_level(int idx){
    if(idx<0)idx=nlevels-1; if(idx>=nlevels)idx=0;
    free_level(); cur_level=idx; in_menu=0;
    char path[160]; snprintf(path,sizeof path,"romfs:/levels/%s.lvl",level_names[idx]);
    size_t sz; uint8_t *b=readf(path,&sz); if(!b)return -1;
    uint8_t *p=b; if(memcmp(p,"EL03",4)){free(b);return -2;} p+=4;
    uint32_t nu; memcpy(&nu,p,4);p+=4; L.nused=nu; L.used=malloc(2*(nu?nu:1)); memcpy(L.used,p,2*nu); p+=2*nu; if(nu&1)p+=2;
    uint32_t c[7]; memcpy(c,p,28);p+=28;
    L.ntile=c[0];L.nspr=c[1];L.ncol=c[2];L.nent=c[3];L.nmodel=c[4];L.nmspr=c[5];L.nmcol=c[6];
    #define TAKE(dst,T,n) do{ dst=malloc(sizeof(T)*((n)?(n):1)); memcpy(dst,p,sizeof(T)*(n)); p+=sizeof(T)*(n);}while(0)
    TAKE(L.tiles,Tile,L.ntile); TAKE(L.spr,Spr,L.nspr); TAKE(L.col,Col,L.ncol);
    EntRec *er; TAKE(er,EntRec,L.nent);
    TAKE(L.model,ModelRec,L.nmodel); TAKE(L.mspr,Spr,L.nmspr); TAKE(L.mcol,Col,L.nmcol);
    free(b);
    for(int i=0;i<L.nused;i++){ int id=L.used[i]; char tp[64]; snprintf(tp,sizeof tp,"romfs:/tex/%04d.bin",id);
        if(tex_loaded[id])continue;
        size_t ts; uint8_t *d=readf(tp,&ts); if(!d)continue;
        plat_tex_create(id,texinfo[id].w,texinfo[id].h,texinfo[id].tw,texinfo[id].th,d); free(d); tex_loaded[id]=1; }
    // entities
    L.ent=calloc(L.nent?L.nent:1,sizeof(Ent));
    memset(&P,0,sizeof P); P.hp=100; P.ent=-1; g_vs=VS0;
    for(int i=0;i<L.nent;i++){
        Ent*e=&L.ent[i]; EntRec*r=&er[i]; ModelRec*m=&L.model[r->model];
        memcpy(e->name,m->name,24); e->kind=kind_of(e->name); e->model=r->model; e->z=r->z;
        e->x=r->m[4]; e->y=r->m[5]; e->rot=atan2f(r->m[1],r->m[0]);
        e->sx=hypotf(r->m[0],r->m[1]); e->sy=hypotf(r->m[2],r->m[3]); if(r->m[0]*r->m[3]-r->m[1]*r->m[2]<0)e->sy=-e->sy;
        e->hp=r->hp; e->speed=r->speed; e->dmg=r->dmg; e->sight=r->sight; e->alive=1;
        switch(e->kind){case K_ZOMBIE:e->r=24;break;case K_RAT:e->r=14;break;case K_MONKEY:e->r=28;break;default:e->r=m->rad>8?m->rad:24;}
        if(e->kind==K_PLAYER){P.ent=i;P.x=e->x;P.y=e->y;P.face=e->rot;}
    }
    free(er);
    if(P.ent<0){ for(int i=0;i<L.nent;i++)if(L.ent[i].kind==K_EXIT){P.x=L.ent[i].x;P.y=L.ent[i].y;break;} }
    cam_x=P.x;cam_y=P.y;
    // solid grid hash
    L.cellsz=32; int ns=0; for(int i=0;i<L.ntile;i++) if(L.tiles[i].fl&8) ns++;
    L.hsize=ns*3+17; L.hkx=calloc(L.hsize,4);L.hky=calloc(L.hsize,4);L.hocc=calloc(L.hsize,1);
    for(int i=0;i<L.ntile;i++) if(L.tiles[i].fl&8){
        Tile*t=&L.tiles[i]; int x0=(int)floorf(t->x/32.f+0.01f),y0=(int)floorf(t->y/32.f+0.01f);
        int w=(int)((t->sw+31)/32),h=(int)((t->sh+31)/32); for(int yy=0;yy<h;yy++)for(int xx=0;xx<w;xx++)hset(x0+xx,y0+yy);
    }
    // draw list
    L.ndraw=L.ntile+L.nspr+L.nent; L.draw=malloc(sizeof(DItem)*(L.ndraw?L.ndraw:1)); int k=0;
    for(int i=0;i<L.ntile;i++){L.draw[k++]=(DItem){L.tiles[i].z,0,i};}
    for(int i=0;i<L.nspr;i++){L.draw[k++]=(DItem){L.spr[i].z,1,i};}
    for(int i=0;i<L.nent;i++){ Ent*e=&L.ent[i]; int z=e->z; ModelRec*m=&L.model[e->model]; if(m->ns)z+=L.mspr[m->fs].z; if(e->kind==K_PLAYER)z=30000; L.draw[k++]=(DItem){(int16_t)z,2,i}; }
    qsort(L.draw,L.ndraw,sizeof(DItem),cmp_draw);
    tracer.t=0; acc=0;
    if(strcmp(cur_music,level_music[idx])){ snprintf(cur_music,32,"%s",level_music[idx]); plat_music(cur_music[0]?cur_music:NULL); }
    return 0;
}
int engine_player_dead(void){return P.dead_t>0;}

/* ---------------- collision ---------------- */
static int col_active(const Col*c){
    if(c->owner>=0&&c->owner<L.nent){ if(L.ent[c->owner].kind==K_DOOR&&L.ent[c->owner].open>0.5f)return 0; }
    return 1;
}
// push circle (cx,cy,r) out of solids. returns 1 if pushed
static int push_out(float *cx,float *cy,float r){
    int hit=0;
    for(int iter=0;iter<3;iter++){
        int x0=(int)floorf((*cx-r)/32.f),x1=(int)floorf((*cx+r)/32.f),y0=(int)floorf((*cy-r)/32.f),y1=(int)floorf((*cy+r)/32.f);
        for(int gy=y0;gy<=y1;gy++)for(int gx=x0;gx<=x1;gx++){
            if(!hget(gx,gy))continue;
            float bx0=gx*32.f,by0=gy*32.f,bx1=bx0+32.f,by1=by0+32.f;
            float nx=clampf(*cx,bx0,bx1),ny=clampf(*cy,by0,by1);
            float dx=*cx-nx,dy=*cy-ny,d2=dx*dx+dy*dy;
            if(d2<r*r){
                if(d2>1e-6f){float d=sqrtf(d2);*cx+=dx/d*(r-d);*cy+=dy/d*(r-d);}
                else { float l=*cx-bx0,rr=bx1-*cx,t=*cy-by0,bb=by1-*cy,m=fminf(fminf(l,rr),fminf(t,bb));
                    if(m==l)*cx=bx0-r;else if(m==rr)*cx=bx1+r;else if(m==t)*cy=by0-r;else *cy=by1+r; }
                hit=1;
            }
        }
        for(int i=0;i<L.ncol;i++){
            Col*c=&L.col[i]; if(!col_active(c))continue;
            float a=c->m[0],b=c->m[1],cc=c->m[2],d=c->m[3],e=c->m[4],f=c->m[5];
            if(c->kind==1){ float rad=c->hx*fmaxf(hypotf(a,b),hypotf(cc,d)); float dx=*cx-e,dy=*cy-f,dist=hypotf(dx,dy);
                if(dist<rad+r&&dist>1e-4f){*cx=e+dx/dist*(rad+r);*cy=f+dy/dist*(rad+r);hit=1;} continue; }
            float det=a*d-b*cc; if(fabsf(det)<1e-9f)continue;
            float ix=(*cx-e),iy=(*cy-f);
            float lx=( d*ix-cc*iy)/det, ly=(-b*ix+a*iy)/det;       // to box-local
            float sx=hypotf(a,b),sy=hypotf(cc,d);
            if(fabsf(*cx-e)>c->hx*sx+c->hy*sy+r+2||fabsf(*cy-f)>c->hx*sx+c->hy*sy+r+2)continue;
            float nx=clampf(lx,-c->hx,c->hx),ny=clampf(ly,-c->hy,c->hy);
            float dx=(lx-nx)*sx,dy=(ly-ny)*sy; // approx in world units
            float d2=dx*dx+dy*dy;
            if(d2<r*r){
                float wx,wy;
                if(d2>1e-6f){ float dd=sqrtf(d2); float push=r-dd; // push direction in local -> world
                    float ux=(lx-nx),uy=(ly-ny); float ul=hypotf(ux,uy); ux/=ul;uy/=ul;
                    wx=(a*ux+cc*uy);wy=(b*ux+d*uy); float wl=hypotf(wx,wy); wx/=wl;wy/=wl; *cx+=wx*push;*cy+=wy*push; }
                else { // centre inside box: push along smallest axis
                    float px=c->hx-fabsf(lx),py=c->hy-fabsf(ly); float ux=0,uy=0;
                    if(px*sx<py*sy)ux=lx<0?-1:1;else uy=ly<0?-1:1;
                    wx=(a*ux+cc*uy);wy=(b*ux+d*uy); float wl=hypotf(wx,wy);wx/=wl;wy/=wl;
                    float mv=fminf(px*sx,py*sy)+r; *cx+=wx*mv;*cy+=wy*mv; }
                hit=1;
            }
        }
    }
    return hit;
}
static int ray_blocked(float x0,float y0,float x1,float y1){
    float dx=x1-x0,dy=y1-y0,len=hypotf(dx,dy); int n=(int)(len/8)+1;
    for(int i=1;i<=n;i++){ float t=(float)i/n; float x=x0+dx*t,y=y0+dy*t;
        if(hget((int)floorf(x/32.f),(int)floorf(y/32.f)))return 1;
        for(int k=0;k<L.ncol;k++){ Col*c=&L.col[k]; if(!col_active(c))continue; if(c->kind==1)continue;
            float a=c->m[0],b=c->m[1],cc=c->m[2],d=c->m[3],e=c->m[4],f=c->m[5]; float det=a*d-b*cc; if(fabsf(det)<1e-9f)continue;
            float ix=x-e,iy=y-f; float lx=(d*ix-cc*iy)/det,ly=(-b*ix+a*iy)/det;
            if(fabsf(lx)<c->hx&&fabsf(ly)<c->hy)return 1; } }
    return 0;
}
static float ray_wall_dist(float x,float y,float dx,float dy,float maxd){
    for(float t=8;t<maxd;t+=8) if(ray_blocked(x+dx*(t-8),y+dy*(t-8),x+dx*t,y+dy*t))return t;
    return maxd;
}

/* ---------------- simulation ---------------- */
static void alert_enemies(float x,float y,float rad){
    for(int i=0;i<L.nent;i++){Ent*e=&L.ent[i]; if(e->alive&&(e->kind==K_ZOMBIE||e->kind==K_RAT)&&hypotf(e->x-x,e->y-y)<rad)e->aware=1;}
}
static void shoot(void){
    /* every trigger pull turns the cylinder one slot; only a loaded slot fires (as in the original) */
    int can=P.slots[P.ready]==1, slot=P.ready; P.ready=(P.ready+1)%6; P.rot=P.ready*6.2831853f/6.f;
    if(!can){ plat_sfx("dry_fire"); return; }
    P.slots[slot]=2; { static const char*sn[3]={"revolver_shot1","revolver_shot2","revolver_shot3"}; plat_sfx(sn[sfx_n++%3]); }
    float dx=P.hx,dy=P.hy,l=hypotf(dx,dy); if(l<1){dx=cosf(P.face);dy=sinf(P.face);}else{dx/=l;dy/=l;}
    float ox=P.x+dx*30,oy=P.y+dy*30;
    float wall=ray_wall_dist(ox,oy,dx,dy,1100.f),best=wall; int hit=-1;
    for(int i=0;i<L.nent;i++){Ent*e=&L.ent[i]; if(!e->alive||!(e->kind==K_ZOMBIE||e->kind==K_RAT||e->kind==K_MONKEY||e->kind==K_ENEMY_STATIC))continue;
        float vx=e->x-ox,vy=e->y-oy,t=vx*dx+vy*dy; if(t<0||t>best)continue;
        float px=ox+dx*t-e->x,py=oy+dy*t-e->y; if(px*px+py*py<e->r*e->r){best=t;hit=i;} }
    if(hit>=0){Ent*e=&L.ent[hit]; e->hp-=1; e->stun=6; e->aware=1; if(e->hp<=0){e->alive=0;plat_sfx("SpikrDeath-001");} else plat_sfx((sfx_n&1)?"SpikrHurt-001":"SpikrHurt-002");}
    tracer.x0=ox;tracer.y0=oy;tracer.x1=ox+dx*best;tracer.y1=oy+dy*best;tracer.t=5;
    alert_enemies(P.x,P.y,700);
    P.x-=dx*5;P.y-=dy*5; push_out(&P.x,&P.y,PLAYER_R);
}
static void hurt_player(int d){ if(P.dead_t>0)return; P.hp-=d; P.hurt=12; if(P.hp<=0){P.hp=0;P.dead_t=120;plat_sfx("player_die");} else plat_sfx((sfx_n++&1)?"player_hurt":"player_hurt2"); }

/* ---- inventory: positions in "UI space" = world units around the screen centre (the player is always centred) ---- */
static void slot_pos(int i,float*ox,float*oy){ float r=P.rot,c=cosf(r),s=sinf(r),R[6]={c,s,-s,c,0,0},m[6]; mmul(UI.pivot,R,m);
    float qx=UI.slots[i][0],qy=UI.slots[i][1]; *ox=m[0]*qx+m[2]*qy+m[4]; *oy=m[1]*qx+m[3]*qy+m[5]; }
static void bullet_pos(int i,float*ox,float*oy){ const float*t=UI.ammoTf; float x=(float)(i/2)*50.f,y=(i%2==0)?-140.f:0.f; *ox=t[0]*(x+27.5f)+t[4]; *oy=t[3]*(y-66.5f)+t[5]; }
static void syr_pos(int i,float*ox,float*oy){ *ox=UI.syrTf[4]+i*20.f; *oy=UI.syrTf[5]; }
static float para_y(void){ return UI.pStartY+(UI.pEndY-UI.pStartY)*(1.f-(float)P.hp/100.f); }
static void open_inv(void){ if(P.inv)return; P.inv=1; P.curx=P.cury=0; P.grab=0; P.dragging=0; plat_sfx("click"); }
static void close_inv(void){
    if(!P.inv)return; P.inv=0; P.grab=0; float bd=1e18f; int bi=P.ready;
    for(int i=0;i<6;i++){ float x,y; slot_pos(i,&x,&y); float d=(x-UI.next[4])*(x-UI.next[4])+(y-UI.next[5])*(y-UI.next[5]); if(d<bd){bd=d;bi=i;} }
    P.ready=bi; P.rot=P.ready*6.2831853f/6.f; plat_sfx("click");
}
static void inv_tick(const Input*in,float dx,float dy,int first){
    if(first){ P.curx=clampf(P.curx+dx*2.5f,-400,400); P.cury=clampf(P.cury+dy*2.5f,-300,300); }
    float cx=P.curx,cy=P.cury;
    if(in->a_pressed&&first&&!P.grab){
        for(int i=0;i<P.syr;i++){ float x,y; syr_pos(i,&x,&y); if(fabsf(cx-x)<=18&&cy>=y-108&&cy<=y+58){P.grab=3;plat_sfx("grab_thing");return;} }
        for(int i=0;i<P.ammo;i++){ float x,y; bullet_pos(i,&x,&y); if(fabsf(cx-x)<=27*0.8f+8&&fabsf(cy-y)<=67*0.8f+8){P.grab=1;plat_sfx("grab_thing");return;} }
        for(int i=0;i<6;i++){ if(P.slots[i]!=2)continue; float x,y; slot_pos(i,&x,&y); if(hypotf(cx-x,cy-y)<=UI.slotR){P.slots[i]=0;P.grab=2;plat_sfx("grab_thing");return;} }
    }
    if(P.grab){
        if(P.grab==3){ /* dragging a syringe over the parasite injects it */
            float px=UI.parasiteHit[4],py=para_y()+(UI.parasiteHit[5]-UI.parasite.m[5]);
            if(hypotf(cx-px,cy-py)<45){ P.syr--; P.hp=P.hp+50>100?100:P.hp+50; P.grab=0; plat_sfx("grab_thing"); return; } }
        if(!in->a_held){
            if(P.grab==1){ const float*d=UI.dropTf; int in_drop=fabsf(cx-d[4])<16*d[0]&&fabsf(cy-d[5])<16*d[3]; int done=0;
                if(in_drop){P.ammo--;done=1;}
                else for(int i=0;i<6&&!done;i++){ float x,y; slot_pos(i,&x,&y); if(hypotf(cx-x,cy-y)<=UI.slotR&&P.slots[i]==0){P.slots[i]=1;P.ammo--;plat_sfx("revolver_return_bullet");done=1;} } }
            P.grab=0; }
    }
}
static void tick_player(const Input*in,float dx,float dy,int first){
    if(P.dead_t>0){ P.dead_t--; if(P.dead_t==0)engine_load_level(cur_level); return; }
    if(first&&UI.ok){ /* circle pad = mouse wheel: up opens, up again spins the chamber, down closes */
        if(in->scroll>0){ if(!P.inv)open_inv(); else { P.rot+=10.f*0.0174533f; plat_sfx("slide_step"); } }
        else if(in->scroll<0&&P.inv)close_inv(); }
    if(P.inv){ inv_tick(in,dx,dy,first); if(P.hurt>0)P.hurt--; return; }
    if(in->b_pressed&&first&&P.has_gun){ /* right click on the holster at your side takes the revolver out / puts it away */
        float c=cosf(P.face),s=sinf(P.face),hx=P.x+c*6-s*56,hy=P.y+s*6+c*56,hd=hypotf(P.x+P.hx-hx,P.y+P.hy-hy);
        if(!P.gun_out&&hd<30){P.gun_out=1;plat_sfx("revolver_equip");} else if(P.gun_out&&hd<40){P.gun_out=0;plat_sfx("revolver_unequip");} }
    int gun=P.gun_out&&P.has_gun;
    int was=P.dragging;
    if(in->a_held&&!gun){
        if(!was){ P.dragging=1; P.gx=P.x+P.hx; P.gy=P.y+P.hy; P.nmv=0; plat_sfx("grab_ground"); }
        // pull body against the grabbed hand
        float mvx=dx*TOUCH_K,mvy=dy*TOUCH_K; float l=hypotf(mvx,mvy); if(l>MAX_DRAG){mvx*=MAX_DRAG/l;mvy*=MAX_DRAG/l;}
        float nx=P.x-mvx,ny=P.y-mvy;
        if(hypotf(nx-P.gx,ny-P.gy)>ARM_LEN){ mvx=mvy=0; }
        else { P.x=nx;P.y=ny; }
        if(P.nmv<10){P.mv[P.nmv][0]=mvx;P.mv[P.nmv][1]=mvy;P.nmv++;} else {memmove(P.mv[0],P.mv[1],sizeof(float)*2*9);P.mv[9][0]=mvx;P.mv[9][1]=mvy;}
        if(mvx*mvx+mvy*mvy>16.f){ static int st=0; if(++st%14==0)plat_sfx((st&1)?"slide_step":"slide_step2"); }
        if(mvx||mvy)P.face=atan2f(mvy,mvx); // body turns toward travel (-move_vec)
        push_out(&P.x,&P.y,PLAYER_R);
        P.hx=P.gx-P.x;P.hy=P.gy-P.y;
    } else {
        if(was){ P.dragging=0; float sx=0,sy=0; for(int i=0;i<P.nmv;i++){sx+=P.mv[i][0];sy+=P.mv[i][1];} P.slide_x=-sx/20.f;P.slide_y=-sy/20.f; P.nmv=0; }
        if(P.slide_x*P.slide_x+P.slide_y*P.slide_y>0.01f){ P.x+=P.slide_x;P.y+=P.slide_y;P.slide_x*=0.75f;P.slide_y*=0.75f; push_out(&P.x,&P.y,PLAYER_R); }
        // hand follows the touchpad within arm reach
        P.hx+=dx*TOUCH_K;P.hy+=dy*TOUCH_K; float hl=hypotf(P.hx,P.hy); if(hl>ARM_LEN){P.hx*=ARM_LEN/hl;P.hy*=ARM_LEN/hl;}
        if(hl>8) P.face=atan2f(P.hy,P.hx);
        if(gun&&in->a_pressed&&first)shoot();
    }
    if(P.hurt>0)P.hurt--;
}
static void tick_enemies(void){
    for(int i=0;i<L.nent;i++){Ent*e=&L.ent[i];
        if(e->kind==K_DOOR){ float d=hypotf(e->x-P.x,e->y-P.y); float tgt=d<190.f?1.f:0.f; float po=e->open; e->open+= (tgt>e->open?0.08f:-0.04f); e->open=clampf(e->open,0,1); if(po==0&&e->open>0)plat_sfx("SmallDoorOpen-001"); if(po>0&&e->open==0)plat_sfx("SmallDoorClose-001"); continue; }
        if(e->taken)continue;
        if(e->kind==K_BULLETS||e->kind==K_HEALTH||e->kind==K_GUN){
            float d=hypotf(e->x-P.x,e->y-P.y),dh=hypotf(e->x-(P.x+P.hx),e->y-(P.y+P.hy));
            if(d<PLAYER_R+30||dh<34){
                if(e->kind==K_BULLETS){ int amt=(int)e->hp; if(amt<=0)amt=3; int n=amt<6-P.ammo?amt:6-P.ammo; if(n<=0)continue; P.ammo+=n; e->hp-=n; plat_sfx("pickup_revolver_bulelts"); if(e->hp>0)continue; }
                else if(e->kind==K_HEALTH){ if(P.syr>=3)continue; P.syr++; plat_sfx("grab_thing"); }
                else { P.has_gun=1; plat_sfx("revolver_equip"); }
                e->taken=1; }
            continue; }
        if(e->kind==K_EXIT){ if(hypotf(e->x-P.x,e->y-P.y)<PLAYER_R+60&&P.dead_t==0){ engine_load_level(cur_level+1); return; } continue; }
        if(e->kind!=K_ZOMBIE&&e->kind!=K_RAT)continue;
        if(!e->alive)continue;
        float dx=P.x-e->x,dy=P.y-e->y,d=hypotf(dx,dy);
        if(!e->aware){ if(d<e->sight&&P.dead_t==0&&!ray_blocked(e->x,e->y,P.x,P.y))e->aware=1; else continue; }
        if(e->stun>0){e->stun--;continue;}
        if(e->cooldown>0)e->cooldown--;
        float want=atan2f(dy,dx),diff=want-e->rot; while(diff>3.14159f)diff-=6.28318f; while(diff<-3.14159f)diff+=6.28318f;
        float turn=140.f*0.0174533f*TICK; if(fabsf(diff)<turn)e->rot=want;else e->rot+=diff>0?turn:-turn;
        float reach=e->r+PLAYER_R+8;
        if(e->windup>0){ e->windup--; if(e->windup==0&&d<reach+20)hurt_player((int)e->dmg); continue; }
        if(d<reach){ if(e->cooldown==0){e->windup=18;e->cooldown=75;plat_sfx((sfx_n++&1)?"SpikrSpectralZombieAttack-001":"SpikrSpectralZombieAttack-002");} continue; }
        float sp=e->speed*TICK; float nx=e->x+cosf(e->rot)*sp,ny=e->y+sinf(e->rot)*sp;
        push_out(&nx,&ny,e->r);
        float ddx=nx-P.x,ddy=ny-P.y,dd=hypotf(ddx,ddy); if(dd<e->r+PLAYER_R){nx=P.x+ddx/dd*(e->r+PLAYER_R);ny=P.y+ddy/dd*(e->r+PLAYER_R);}
        e->x=nx;e->y=ny;
    }
}
void engine_update(const Input *in,float dt){
    if(in_menu){
        if(in->menu_up&&menu_sel>0)menu_sel--; if(in->menu_down&&menu_sel<nlevels-1)menu_sel++;
        if(menu_sel<menu_top)menu_top=menu_sel; if(menu_sel>=menu_top+7)menu_top=menu_sel-6;
        if(in->a_pressed){ cur_music[0]=0; engine_load_level(menu_sel); }
        return; }
    if(in->select_pressed){ in_menu=1; menu_sel=cur_level<0?0:cur_level; plat_music("labs_track"); cur_music[0]=0; return; }
    if(cur_level<0)return;
    if(in->next_level){engine_load_level(cur_level+1);return;}
    if(in->prev_level){engine_load_level(cur_level-1);return;}
    acc+=dt; if(acc>0.1f)acc=0.1f; int first=1;
    /* keep one-shot presses and touch movement until a game tick consumes them (a frame can be shorter than one tick) */
    static int pa=0,pb=0,py=0,px_=0,psc=0; static float pdx=0,pdy=0;
    pa|=in->a_pressed!=0; pb|=in->b_pressed!=0; py|=in->y_pressed!=0; px_|=in->x_pressed!=0; if(in->scroll)psc=in->scroll; pdx+=(float)in->touch_dx; pdy+=(float)in->touch_dy;
    int n=0; float a2=acc; while(a2>=TICK){n++;a2-=TICK;}
    for(int s=0;s<n;s++){ Input ti=*in; if(first){ ti.a_pressed=pa; ti.b_pressed=pb; ti.y_pressed=py; ti.x_pressed=px_; ti.scroll=psc; } else { ti.a_pressed=ti.b_pressed=ti.y_pressed=ti.x_pressed=0; ti.scroll=0; }
        tick_player(&ti,first?pdx:0,first?pdy:0,first); if(first){ pa=pb=py=px_=psc=0; pdx=pdy=0; } tick_enemies(); first=0; if(tracer.t>0)tracer.t--; }
    acc=a2; frame_t+=dt;
    cam_x=P.x; cam_y=P.y;   /* camera locked to the player: the darkness circle never lags */
    g_vs=P.inv?VSI:VS0;
}

/* ---------------- drawing ---------------- */
static void mmul(const float*p,const float*q,float*o){
    float r[6]={p[0]*q[0]+p[2]*q[1],p[1]*q[0]+p[3]*q[1],p[0]*q[2]+p[2]*q[3],p[1]*q[2]+p[3]*q[3],p[0]*q[4]+p[2]*q[5]+p[4],p[1]*q[4]+p[3]*q[5]+p[5]};
    memcpy(o,r,sizeof r);
}
static uint32_t pack(const uint8_t*c,float mul_a,float mul_rgb){ int r=c[0]*mul_rgb,g=c[1]*mul_rgb,b=c[2]*mul_rgb,a=c[3]*mul_a; if(r>255)r=255;if(g>255)g=255;if(b>255)b=255;if(a>255)a=255; return r|(g<<8)|(b<<16)|((uint32_t)a<<24); }
static void draw_spr(const Spr*s,const float*parent,float ma,float mr){
    float M[6]; memcpy(M,parent,sizeof M);
    float W[6]; mmul(M,s->m,W);
    float F[6]={(s->fl&1)?-1:1,0,0,(s->fl&2)?-1:1,s->ox+((s->fl&1)?s->sw:0),s->oy+((s->fl&2)?s->sh:0)};
    float Wf[6]; mmul(W,F,Wf); plat_draw(s->tex,s->sx,s->sy,s->sw,s->sh,Wf,pack(s->c,ma,mr));
}
static void rect(float x,float y,float w,float h,uint32_t rgba){ float M[6]={w,0,0,h,x,y}; plat_draw(0,0,0,1,1,M,rgba); }
static void line_world(const float*V,float x0,float y0,float x1,float y1,float th,uint32_t rgba){
    float dx=x1-x0,dy=y1-y0,l=hypotf(dx,dy); if(l<0.5f)return; float ux=dx/l,uy=dy/l;
    float M[6]={ux*l,uy*l,-uy*th,ux*th,x0+uy*th*0.5f,y0-ux*th*0.5f}; float W[6]; mmul(V,M,W); plat_draw(0,0,0,1,1,W,rgba);
}
static void text(const char*s,float x,float y,float sc,uint32_t col){
    for(;*s;s++,x+=6*sc){ const char*p=strchr(FONT_CHARS,*s); if(!p||*s==0)continue; int i=(int)(p-FONT_CHARS);
        float M[6]={sc,0,0,sc,x,y}; plat_draw(FONT_ID,(i%8)*8,(i/8)*8,6,8,M,col); } }
static void draw_menu(void){
    rect(0,0,VIEW_W,VIEW_H,0xFF101014);
    text("ENDOPARASITIC",38,14,4,0xFF9090F0); text("3DS PORT",150,52,2,0xFFB0B0B0);
    for(int i=0;i<7;i++){ int k=menu_top+i; if(k>=nlevels)break; float y=76+i*20;
        if(k==menu_sel){ rect(24,y-3,352,19,0xFF704030); text(">",30,y,2,0xFF40D0FF); }
        text(disp[k],54,y,2,k==menu_sel?0xFFFFFFFF:0xFF909090); }
    text("UP/DOWN: SELECT   A: START",64,226,1,0xFF808080);
    if(nlevels>7){ float h=7.f*21/nlevels*7; rect(386,82+(float)menu_top/nlevels*147,3,h>8?h:8,0xFF606060); }
}
static void ds(const USpr*it,const float*tf,int own,uint32_t col){
    float T[6]={1,0,0,1,it->ox,it->oy},A[6],UVm[6]={g_vs,0,0,g_vs,VIEW_W/2.f,VIEW_H/2.f},B[6]; mmul(tf,T,A); mmul(UVm,A,B);
    plat_draw(it->tex,it->sx,it->sy,it->sw,it->sh,B,own?pack(it->c,1,1):col); }
static void draw_inv(void){
    rect(0,0,VIEW_W,VIEW_H,0x46000000);
    ds(&UI.brainBack,UI.brainBack.m,1,0); ds(&UI.brain,UI.brain.m,1,0);
    float dy=para_y()-UI.parasite.m[5]; { const USpr*k[3]={&UI.parasiteBack,&UI.parasite,&UI.legs}; for(int i=0;i<3;i++){ float t[6]; memcpy(t,k[i]->m,sizeof t); t[5]+=dy; ds(k[i],t,1,0); } }
    int shownS=P.syr-(P.grab==3?1:0);
    for(int i=0;i<shownS;i++){ float x,y,t[6]={1,0,0,1,0,0}; syr_pos(i,&x,&y); t[4]=x;t[5]=y; ds(&UI.syrBase,t,1,0); ds(&UI.syrTop,t,1,0); }
    float c=cosf(P.rot),s=sinf(P.rot),R[6]={c,s,-s,c,0,0},CM[6]; mmul(UI.pivot,R,CM);
    { float t0[6]; memcpy(t0,CM,sizeof t0); ds(&UI.chamber,t0,1,0); }
    for(int i=0;i<6;i++){ if(P.slots[i]==0)continue; float T[6]={1,0,0,1,UI.slots[i][0],UI.slots[i][1]},tf[6]; mmul(CM,T,tf); ds(P.slots[i]==1?&UI.slotReady:&UI.slotFired,tf,1,0); }
    ds(&UI.handle,UI.handle.m,1,0); ds(&UI.nextSprite,UI.nextSprite.m,1,0);
    int shownB=P.ammo-(P.grab==1?1:0);
    for(int i=0;i<shownB;i++){ float T[6]={1,0,0,1,(float)(i/2)*50.f,(i%2==0)?-140.f:0.f},tf[6]; mmul(UI.ammoTf,T,tf); ds(&UI.bulletIdle,tf,1,0); }
    if(P.grab==1){ const float*d=UI.dropTf; float UVm[6]={g_vs,0,0,g_vs,VIEW_W/2.f,VIEW_H/2.f},M0[6]={32*d[0],0,0,32*d[3],d[4]-16*d[0],d[5]-16*d[3]},M1[6]; mmul(UVm,M0,M1); plat_draw(0,0,0,1,1,M1,0x32C8C8C8); }
    if(P.has_gun)ds(&UI.equipIcon,UI.equipIcon.m,P.gun_out,0xC8969696);
    float hc[6]={0.8f,0,0,0.8f,P.curx,P.cury};
    if(P.grab==1)ds(&UI.bulletHeld,hc,1,0); else if(P.grab==2)ds(&UI.shellHeld,hc,1,0);
    else if(P.grab==3){ float m[6]={0,1,-1,0,P.curx-20,P.cury+35}; ds(&UI.syrBase,m,1,0); ds(&UI.syrTop,m,1,0); }
    rect(VIEW_W/2.f+P.curx*g_vs-5,VIEW_H/2.f+P.cury*g_vs-5,10,10,P.grab?0xFF4B6E96:0xFF96BEE6);
}
void engine_draw(void){
    if(in_menu){ draw_menu(); return; }
    if(cur_level<0)return;
    g_vs=P.inv?VSI:VS0;
    float V[6]={g_vs,0,0,g_vs,roundf(VIEW_W/2-cam_x*g_vs),roundf(VIEW_H/2-cam_y*g_vs)};   // world -> screen
    float vx0=cam_x-VIEW_W/2/g_vs-120,vx1=cam_x+VIEW_W/2/g_vs+120,vy0=cam_y-VIEW_H/2/g_vs-120,vy1=cam_y+VIEW_H/2/g_vs+120;
    for(int k=0;k<L.ndraw;k++){ DItem*it=&L.draw[k];
        if(it->type==0){ Tile*t=&L.tiles[it->idx];
            if(t->x>vx1||t->y>vy1||t->x+t->sw<vx0||t->y+t->sh<vy0)continue;
            float W=t->sw,H=t->sh; float F[6];
            if(t->fl&4){F[0]=0;F[1]=(t->fl&2)?-1:1;F[2]=(t->fl&1)?-1:1;F[3]=0;F[4]=(t->fl&1)?H:0;F[5]=(t->fl&2)?W:0;}
            else {F[0]=(t->fl&1)?-1:1;F[1]=0;F[2]=0;F[3]=(t->fl&2)?-1:1;F[4]=(t->fl&1)?W:0;F[5]=(t->fl&2)?H:0;}
            float T[6]={1,0,0,1,t->x,t->y},A[6],B[6]; mmul(T,F,A); mmul(V,A,B); plat_draw(t->tex,t->sx,t->sy,t->sw,t->sh,B,pack(t->c,1,1));
        } else if(it->type==1){ Spr*s=&L.spr[it->idx];
            float r=hypotf(s->sw,s->sh)*fmaxf(hypotf(s->m[0],s->m[1]),hypotf(s->m[2],s->m[3]))+hypotf(s->ox,s->oy);
            if(s->m[4]+r<vx0||s->m[4]-r>vx1||s->m[5]+r<vy0||s->m[5]-r>vy1)continue;
            draw_spr(s,V,1,1);
        } else { Ent*e=&L.ent[it->idx]; ModelRec*m=&L.model[e->model];
            if(e->taken)continue;
            { float cxp=(e->kind==K_PLAYER)?P.x:e->x,cyp=(e->kind==K_PLAYER)?P.y:e->y; if(cxp<vx0-100||cxp>vx1+100||cyp<vy0-100||cyp>vy1+100)continue; }
            float c,sn; float rot=e->rot,ex=e->x,ey=e->y; if(e->kind==K_PLAYER){rot=P.face;ex=P.x;ey=P.y;}
            c=cosf(rot);sn=sinf(rot);
            float E[6]={c*e->sx,sn*e->sx,-sn*e->sy,c*e->sy,ex,ey},EV[6]; mmul(V,E,EV);
            float ma=1,mr=1; if((e->kind==K_ZOMBIE||e->kind==K_RAT)&&!e->alive){ma=0.8f;mr=0.35f;}
            if(e->kind==K_PLAYER&&P.hurt>0){mr=1.8f;}
            if(e->kind==K_DOOR){
                float o=1.f-e->open; if(o<0.05f)continue;
                for(uint32_t q=0;q<m->nc;q++){ Col*cc=&L.mcol[m->fc+q]; float a[6]; mmul(E,cc->m,a);
                    float R[6]={cc->hx*2,0,0,cc->hy*2,-cc->hx,-cc->hy},B2[6],B3[6]; mmul(a,R,B2); mmul(V,B2,B3); plat_draw(0,0,0,1,1,B3,0xFF404048); }
                continue; }
            float UP[6],LO[6],HA[6]; memcpy(UP,EV,sizeof UP); memcpy(LO,EV,sizeof LO); memcpy(HA,EV,sizeof HA);
            float hx=P.x+P.hx,hy=P.y+P.hy; if(P.dragging){hx=P.gx;hy=P.gy;}
            if(e->kind==K_PLAYER){ /* two-bone arm: same law-of-cosines maths as the original SSS_calc */
                float sx=hx-P.x,sy=hy-P.y,dist=clampf(hypotf(sx,sy),MINHAND,ARM_LEN),a0=atan2f(sy,sx),Bv=0,Cv=0;
                if(dist<UPPER+LOWER){ float c1=(LOWER*LOWER+dist*dist-UPPER*UPPER)/(2*LOWER*dist),c2=(dist*dist+UPPER*UPPER-LOWER*LOWER)/(2*dist*UPPER);
                    float A=acosf(clampf(c1,-1,1)),Bq=acosf(clampf(c2,-1,1))+3.14159265f; Bv=Bq-3.14159265f; Cv=3.14159265f-A-Bq; }
                float sr=a0+Bv,er=Cv,um[6]={cosf(sr),sinf(sr),-sinf(sr),cosf(sr),P.x,P.y},T1[6]={1,0,0,1,UPPER,0},Re[6]={cosf(er),sinf(er),-sinf(er),cosf(er),0,0},T2[6]={1,0,0,1,LOWER,0},t1[6],lm[6],hm[6];
                mmul(T1,Re,t1); mmul(um,t1,lm); mmul(lm,T2,hm); mmul(V,um,UP); mmul(V,lm,LO); mmul(V,hm,HA); }
            for(uint32_t q=0;q<m->ns;q++){ Spr*s=&L.mspr[m->fs+q]; draw_spr(s,s->owner==100?UP:s->owner==101?LO:s->owner==102?HA:EV,ma,mr); }
            if(e->kind==K_PLAYER&&P.gun_out&&P.has_gun){ float hl=hypotf(P.hx,P.hy); float ux=hl>1?P.hx/hl:cosf(P.face),uy=hl>1?P.hy/hl:sinf(P.face);
                line_world(V,hx,hy,hx+ux*34,hy+uy*34,10,0xFF202020); }
        }
    }
    if(tracer.t>0)line_world(V,tracer.x0,tracer.y0,tracer.x1,tracer.y1,3,0xC0A0F0FF);
    if(P.gun_out&&P.has_gun){ float hx=P.x+P.hx,hy=P.y+P.hy,l=hypotf(P.hx,P.hy); if(l>1){ float ux=P.hx/l,uy=P.hy/l; float d=ray_wall_dist(hx,hy,ux,uy,500);
        float ax=hx+ux*d,ay=hy+uy*d; float M[6]={8,0,0,8,ax*g_vs+V[4]-4,ay*g_vs+V[5]-4}; plat_draw(0,0,0,1,1,M,0xFF3030E0);} }
    { // darkness with a light circle around the player
        float px=(P.x-cam_x)*g_vs+VIEW_W/2,py=(P.y-cam_y)*g_vs+VIEW_H/2,S=420; float x0=px-S/2,y0=py-S/2,x1=px+S/2,y1=py+S/2;
        float M[6]={S/VIG_N,0,0,S/VIG_N,x0,y0}; plat_draw(VIG_ID,0,0,VIG_N,VIG_N,M,0xFF000000);
        // the texture maps 64px -> S px; fix scale
        uint32_t dk=0x9E000000;
        if(y0>0)rect(0,0,VIEW_W,y0,dk); if(y1<VIEW_H)rect(0,y1,VIEW_W,VIEW_H-y1,dk);
        float ya=y0<0?0:y0,yb=y1>VIEW_H?VIEW_H:y1; if(x0>0)rect(0,ya,x0,yb-ya,dk); if(x1<VIEW_W)rect(x1,ya,VIEW_W-x1,yb-ya,dk);
    }
    if(P.inv&&UI.ok)draw_inv();
    else if(P.hp<=30&&P.hp>0){ float pulse=0.5f+0.5f*sinf(frame_t*5.5f); uint32_t col=((uint32_t)(40+90*pulse)<<24)|0x0000C8;
        rect(0,0,VIEW_W,6,col); rect(0,VIEW_H-6,VIEW_W,6,col); rect(0,6,6,VIEW_H-12,col); rect(VIEW_W-6,6,6,VIEW_H-12,col); }
    if(P.dead_t>0){ rect(0,0,VIEW_W,VIEW_H,(uint32_t)(0x90000000|0x000010)); }
}
void engine_debug(float*px,float*py,float*hx,float*hy,int*hp,int*ammo,int*held,int*gun,int*alive){
    *px=P.x;*py=P.y;*hx=P.hx;*hy=P.hy;*hp=P.hp; int loaded=0; for(int i=0;i<6;i++)if(P.slots[i]==1)loaded++; *ammo=loaded;*held=P.ammo;*gun=P.has_gun*2+P.gun_out;
    int a=0; for(int i=0;i<L.nent;i++)if((L.ent[i].kind==K_ZOMBIE||L.ent[i].kind==K_RAT)&&L.ent[i].alive)a++; *alive=a;
}
void engine_cheat_gun(void){P.has_gun=1;P.gun_out=1;for(int i=0;i<6;i++)P.slots[i]=1;}
void engine_cheat_set(int ammo,int syr,int hp,int gun,int out,const int*slots){ if(ammo>=0)P.ammo=ammo; if(syr>=0)P.syr=syr; if(hp>=0)P.hp=hp; if(gun>=0)P.has_gun=gun; if(out>=0)P.gun_out=out; if(slots){ for(int i=0;i<6;i++)P.slots[i]=slots[i]; } }
void engine_set_cursor(float x,float y){P.curx=x;P.cury=y;}
void engine_cheat_ready(int r){P.ready=r;P.rot=r*6.2831853f/6.f;}
void engine_inv_info(InvInfo*o){ memset(o,0,sizeof *o); o->open=P.inv;o->grab=P.grab;o->ammo=P.ammo;o->syr=P.syr;o->hp=P.hp;o->ready=P.ready;o->gun=P.has_gun;o->out=P.gun_out;o->rot=P.rot;o->cx=P.curx;o->cy=P.cury;
    for(int i=0;i<6;i++){o->slots[i]=P.slots[i]; slot_pos(i,&o->slot[i][0],&o->slot[i][1]);}
    bullet_pos(0,&o->bullet0[0],&o->bullet0[1]); syr_pos(0,&o->syr0[0],&o->syr0[1]); o->para[0]=UI.parasiteHit[4]; o->para[1]=para_y()+(UI.parasiteHit[5]-UI.parasite.m[5]); }
int engine_nearest_enemy(float*x,float*y){float best=1e9;int f=0;for(int i=0;i<L.nent;i++){Ent*e=&L.ent[i];if(!e->alive||(e->kind!=K_ZOMBIE&&e->kind!=K_RAT))continue;float d=hypotf(e->x-P.x,e->y-P.y);if(d<best){best=d;*x=e->x;*y=e->y;f=1;}}return f;}

void engine_cheat_near_enemy(void){float x,y;if(!engine_nearest_enemy(&x,&y))return;
    for(int k=0;k<16;k++){float a=k*0.3927f;float nx=x+cosf(a)*300,ny=y+sinf(a)*300;float tx=nx,ty=ny;push_out(&tx,&ty,PLAYER_R);
        if(fabsf(tx-nx)<1&&fabsf(ty-ny)<1&&!ray_blocked(nx,ny,x,y)){P.x=nx;P.y=ny;cam_x=nx;cam_y=ny;return;}}}
