// Endoparasitic 3DS port - portable game engine
#ifndef ENGINE_H
#define ENGINE_H
#include <stdint.h>
#include <stddef.h>

#define FONT_ID 4094   // procedural font atlas texture (platform draws it like a solid-colour mask)
#define VIG_ID  4095   // procedural darkness texture
#define VIEW_W 400
#define VIEW_H 240

typedef struct {
    int touching;          // finger on touchpad this frame
    int touch_dx, touch_dy;// touchpad movement since last frame (touch px)
    int a_held, a_pressed; // left click
    int b_pressed;         // right click
    int x_pressed;         // Q
    int y_pressed;         // F
    int scroll;            // circle pad scroll ticks
    int next_level, prev_level; // L / R shoulder (level skip)
    int menu_up, menu_down;     // D-pad up/down (pressed)
    int select_pressed;         // SELECT: back to menu
} Input;

/* ---- platform layer (implemented by the 3DS build and the host test build) ---- */
unsigned char *plat_read_file(const char *path, size_t *size); // malloc'd or NULL
void plat_tex_create(int id, int w, int h, int tw, int th, const void *swizzled_rgba4444);
void plat_tex_free(int id);
// Draw source rect (sx,sy,sw,sh) of texture `id`. M maps rect-local px (0..sw,0..sh) to screen px:
//   X = M[0]*u + M[2]*v + M[4],   Y = M[1]*u + M[3]*v + M[5]
void plat_draw(int id, int sx, int sy, int sw, int sh, const float M[6], uint32_t rgba /*0xAABBGGRR*/);

void plat_sfx(const char *name);    // play a one-shot effect (romfs:/sfx/<name>.raw, 16 kHz mono PCM16)
void plat_music(const char *name);  // loop a track (romfs:/music/<name>.raw) or NULL to stop

/* ---- engine ---- */
int  engine_init(void);                 // reads levels.txt / tex.tbl
int  engine_level_count(void);
int  engine_load_level(int idx);
void engine_update(const Input *in, float dt);
void engine_draw(void);
int  engine_player_dead(void);
// test hooks
void engine_debug(float *px, float *py, float *hx, float *hy, int *hp, int *ammo, int *held, int *gun, int *alive_enemies);
void engine_cheat_gun(void);
typedef struct { int open,grab,ammo,syr,hp,ready,gun,out,slots[6]; float rot,cx,cy,bullet0[2],slot[6][2],syr0[2],para[2]; } InvInfo;
void engine_inv_info(InvInfo*o);
void engine_cheat_set(int ammo,int syr,int hp,int gun,int out,const int*slots);
void engine_set_cursor(float x,float y);
void engine_cheat_ready(int r);
int engine_nearest_enemy(float*x,float*y);
void engine_cheat_near_enemy(void);
#endif
