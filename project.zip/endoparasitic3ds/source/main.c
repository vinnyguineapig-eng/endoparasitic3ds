// Endoparasitic 3DS port - Nintendo 3DS platform layer (citro2d + ndsp)
// Top screen = game.  Bottom screen = black touchpad (backlight off).
//   A = left click (hold + slide the touchpad to grab the ground and drag yourself; with the gun out: shoot)
//   B = right click (hand on your holster: take the revolver out / put it away)
//   Circle pad = mouse wheel (up: open inventory, up again: spin chamber, down: close)
//   X = Q, Y = F (no action in the original game)
//   Menu: D-pad up/down + A.   In game: SELECT = menu, L/R = previous/next level, START = quit
#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "engine.h"

#define MAX_TEX 4096
#define VIG_ID  4095

/* Optional SD-card file  sdmc:/3ds/endoparasitic.cfg  (plain text, one setting per line):
     flip_v=1   draw all textures upside-down-corrected (use if everything appears flipped vertically)
     tint=0     skip colour tinting, alpha only (use if colours look wrong or sprites vanish)
     tint=2     tint by darkening only (default is 1) */
static int g_flip = 0, g_tint = 1;
static void load_cfg(void) {
    FILE *f = fopen("sdmc:/3ds/endoparasitic.cfg", "r"); if (!f) return;
    char ln[64]; int v;
    while (fgets(ln, sizeof ln, f)) { if (sscanf(ln, "flip_v=%d", &v) == 1) g_flip = v; else if (sscanf(ln, "tint=%d", &v) == 1) g_tint = v; }
    fclose(f);
}

/* ------------------------------------------------------------------ files */
unsigned char *plat_read_file(const char *path, size_t *size) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    unsigned char *b = (unsigned char *)malloc((size_t)n + 1);
    if (!b) { fclose(f); return NULL; }
    size_t r = fread(b, 1, (size_t)n, f); (void)r; fclose(f); b[n] = 0; *size = (size_t)n; return b;
}

/* --------------------------------------------------------------- textures */
static C3D_Tex g_tex[MAX_TEX];
static unsigned char g_have[MAX_TEX];
static unsigned short g_tw[MAX_TEX], g_th[MAX_TEX];

void plat_tex_create(int id, int w, int h, int tw, int th, const void *data) {
    (void)w; (void)h;
    if (id < 0 || id >= MAX_TEX) return;
    C3D_Tex *t = &g_tex[id];
    if (!C3D_TexInit(t, tw, th, GPU_RGBA4)) return;
    memcpy(t->data, data, (size_t)tw * th * 2);
    C3D_TexFlush(t);
    C3D_TexSetFilter(t, id == VIG_ID ? GPU_LINEAR : GPU_NEAREST, id == VIG_ID ? GPU_LINEAR : GPU_NEAREST);
    C3D_TexSetWrap(t, GPU_CLAMP_TO_EDGE, GPU_CLAMP_TO_EDGE);
    g_tw[id] = (unsigned short)tw; g_th[id] = (unsigned short)th; g_have[id] = 1;
}
void plat_tex_free(int id) {
    if (id < 0 || id >= MAX_TEX || !g_have[id]) return;
    C3D_TexDelete(&g_tex[id]); g_have[id] = 0;
}

/* Source rect (sx,sy,sw,sh) of texture id, placed by affine matrix M (rect-local px -> screen px). */
void plat_draw(int id, int sx, int sy, int sw, int sh, const float M[6], uint32_t rgba) {
    if (id < 0 || id >= MAX_TEX || !g_have[id]) return;
    float tw = g_tw[id], th = g_th[id];
    Tex3DS_SubTexture st;
    st.width = (u16)sw; st.height = (u16)sh;
    st.left = sx / tw; st.right = (sx + sw) / tw;
    st.top = 1.0f - sy / th; st.bottom = 1.0f - (sy + sh) / th;
    if (g_flip) { float t = st.top; st.top = st.bottom; st.bottom = t; }
    C2D_Image img = { &g_tex[id], &st };

    float a = M[0], b = M[1], c = M[2], d = M[3];
    float lx = hypotf(a, b);
    if (lx < 1e-6f) return;
    float det = a * d - b * c;
    C2D_DrawParams p;
    p.pos.x = M[4]; p.pos.y = M[5];
    p.pos.w = lx * sw; p.pos.h = (det / lx) * sh;     // negative height = mirrored
    p.center.x = 0; p.center.y = 0;
    p.depth = 0.0f; p.angle = atan2f(b, a);

    unsigned r = rgba & 255, g = (rgba >> 8) & 255, bl = (rgba >> 16) & 255, al = (rgba >> 24) & 255;
    C2D_ImageTint tint;
    if (g_tint == 0 && id != 0 && id != VIG_ID && id != FONT_ID) {
        C2D_AlphaImageTint(&tint, al / 255.0f);
    } else if (id == 0 || id == VIG_ID || id == FONT_ID) {
        // solid colour rectangles / darkness overlay: use the colour itself
        C2D_PlainImageTint(&tint, C2D_Color32(r, g, bl, al), 1.0f);
    } else {
        // modulate brightness by mixing toward black; alpha via the tint colour alpha
        float m = (r + g + bl) / (3.0f * 255.0f); if (m > 1.0f) m = 1.0f;
        C2D_PlainImageTint(&tint, C2D_Color32(0, 0, 0, al), 1.0f - m);
    }
    C2D_DrawImage(img, &p, &tint);
}

/* ------------------------------------------------------------------ audio */
#define SFX_RATE 16000
#define NCH_SFX  6
#define MUSIC_CH 7
#define MUS_CHUNK 16384            /* samples per streaming buffer (~1 s) */
typedef struct { char name[48]; s16 *buf; int n; } Sfx;
static Sfx g_sfx[64]; static int g_nsfx = 0;
static ndspWaveBuf g_wb[NCH_SFX]; static int g_next_ch = 0;
static int g_audio = 0;
static FILE *g_mus = NULL; static s16 *g_mbuf[2]; static ndspWaveBuf g_mwb[2];

static Sfx *sfx_get(const char *name) {
    for (int i = 0; i < g_nsfx; i++) if (!strcmp(g_sfx[i].name, name)) return g_sfx[i].buf ? &g_sfx[i] : NULL;
    if (g_nsfx >= 64) return NULL;
    Sfx *s = &g_sfx[g_nsfx++]; snprintf(s->name, sizeof s->name, "%s", name); s->buf = NULL; s->n = 0;
    char path[160]; snprintf(path, sizeof path, "romfs:/sfx/%s.raw", name);
    FILE *f = fopen(path, "rb"); if (!f) return NULL;
    fseek(f, 0, SEEK_END); long bytes = ftell(f); fseek(f, 0, SEEK_SET);
    s->buf = (s16 *)linearAlloc((size_t)bytes);
    if (!s->buf) { fclose(f); return NULL; }
    size_t r = fread(s->buf, 1, (size_t)bytes, f); (void)r; fclose(f);
    s->n = (int)(bytes / 2); DSP_FlushDataCache(s->buf, (size_t)bytes);
    return s;
}
void plat_sfx(const char *name) {
    if (!g_audio) return;
    Sfx *s = sfx_get(name); if (!s || s->n <= 0) return;
    int ch = g_next_ch; g_next_ch = (g_next_ch + 1) % NCH_SFX;
    ndspChnReset(ch);
    ndspChnSetInterp(ch, NDSP_INTERP_LINEAR);
    ndspChnSetRate(ch, SFX_RATE);
    ndspChnSetFormat(ch, NDSP_FORMAT_MONO_PCM16);
    float mix[12] = {0}; mix[0] = 1.0f; mix[1] = 1.0f; ndspChnSetMix(ch, mix);
    memset(&g_wb[ch], 0, sizeof g_wb[ch]);
    g_wb[ch].data_vaddr = s->buf; g_wb[ch].nsamples = s->n; g_wb[ch].looping = false;
    ndspChnWaveBufAdd(ch, &g_wb[ch]);
}
static int mus_fill(int i) {
    if (!g_mus) return 0;
    size_t got = fread(g_mbuf[i], 2, MUS_CHUNK, g_mus);
    if (got < MUS_CHUNK) { fseek(g_mus, 0, SEEK_SET); size_t more = fread(g_mbuf[i] + got, 2, MUS_CHUNK - got, g_mus); got += more; }
    if (!got) return 0;
    DSP_FlushDataCache(g_mbuf[i], got * 2);
    g_mwb[i].data_vaddr = g_mbuf[i]; g_mwb[i].nsamples = (u32)got; g_mwb[i].looping = false;
    ndspChnWaveBufAdd(MUSIC_CH, &g_mwb[i]);
    return 1;
}
void plat_music(const char *name) {
    if (!g_audio) return;
    ndspChnReset(MUSIC_CH);
    if (g_mus) { fclose(g_mus); g_mus = NULL; }
    if (!name) return;
    char path[160]; snprintf(path, sizeof path, "romfs:/music/%s.raw", name);
    g_mus = fopen(path, "rb"); if (!g_mus) return;
    ndspChnSetInterp(MUSIC_CH, NDSP_INTERP_LINEAR);
    ndspChnSetRate(MUSIC_CH, SFX_RATE);
    ndspChnSetFormat(MUSIC_CH, NDSP_FORMAT_MONO_PCM16);
    float mix[12] = {0}; mix[0] = 0.45f; mix[1] = 0.45f; ndspChnSetMix(MUSIC_CH, mix);
    for (int i = 0; i < 2; i++) { memset(&g_mwb[i], 0, sizeof g_mwb[i]); g_mwb[i].status = NDSP_WBUF_DONE; }
    mus_fill(0); mus_fill(1);
}
static void music_update(void) {
    if (!g_mus) return;
    for (int i = 0; i < 2; i++) if (g_mwb[i].status == NDSP_WBUF_DONE) mus_fill(i);
}

/* ------------------------------------------------------------------- main */
int main(void) {
    gfxInitDefault();
    romfsInit();
    load_cfg();
    osSetSpeedupEnable(true);                    // New 3DS only; ignored on old models
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(6000);
    C2D_Prepare();
    C3D_RenderTarget *top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);

    if (R_SUCCEEDED(ndspInit())) {
        g_audio = 1; ndspSetOutputMode(NDSP_OUTPUT_STEREO);
        for (int i = 0; i < 2; i++) g_mbuf[i] = (s16 *)linearAlloc(MUS_CHUNK * 2);
    }
    gspLcdInit();
    GSPLCD_PowerOffBacklight(GSPLCD_SCREEN_BOTTOM);   // bottom screen black; touch still works

    int ok = (engine_init() == 0);      // starts on the level-select menu
    if (!ok) {   // fatal: show a message on the top screen
        consoleInit(GFX_TOP, NULL);
        printf("Could not load game data (romfs).\nBuild with the romfs folder.\n\nPress START.\n");
        while (aptMainLoop()) { hidScanInput(); if (hidKeysDown() & KEY_START) break; gfxFlushBuffers(); gfxSwapBuffers(); gspWaitForVBlank(); }
        goto quit;
    }

    int was_touch = 0, lx = 0, ly = 0;
    u64 last = osGetTime();
    while (aptMainLoop()) {
        hidScanInput();
        u32 down = hidKeysDown(), held = hidKeysHeld();
        if (down & KEY_START) break;

        Input in; memset(&in, 0, sizeof in);
        in.a_held = (held & KEY_A) != 0; in.a_pressed = (down & KEY_A) != 0;
        in.b_pressed = (down & KEY_B) != 0; in.x_pressed = (down & KEY_X) != 0; in.y_pressed = (down & KEY_Y) != 0;
        in.next_level = (down & KEY_R) != 0; in.prev_level = (down & KEY_L) != 0;
        in.menu_up = (down & KEY_DUP) != 0; in.menu_down = (down & KEY_DDOWN) != 0; in.select_pressed = (down & KEY_SELECT) != 0;
        if (held & KEY_TOUCH) {
            touchPosition tp; hidTouchRead(&tp);
            in.touching = 1;
            if (was_touch) { in.touch_dx = (int)tp.px - lx; in.touch_dy = (int)tp.py - ly; }
            lx = tp.px; ly = tp.py; was_touch = 1;
        } else was_touch = 0;
        /* circle pad = mouse wheel: one tick when pushed up/down, repeating every 14 frames while held */
        circlePosition cp; hidCircleRead(&cp);
        { static int sc_state = 0, sc_hold = 0; int raw = (cp.dy > 40) ? 1 : (cp.dy < -40) ? -1 : 0;
          if (raw != sc_state) { sc_state = raw; sc_hold = 0; in.scroll = raw; }
          else if (raw != 0 && ++sc_hold >= 14) { sc_hold = 0; in.scroll = raw; } }

        u64 now = osGetTime(); float dt = (now - last) / 1000.0f; last = now; if (dt > 0.05f) dt = 0.05f;
        engine_update(&in, dt);
        music_update();

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TargetClear(top, C2D_Color32(0, 0, 0, 255));
        C2D_SceneBegin(top);
        engine_draw();
        C3D_FrameEnd(0);
    }
quit:
    if (g_mus) fclose(g_mus);
    GSPLCD_PowerOnBacklight(GSPLCD_SCREEN_BOTTOM);
    gspLcdExit();
    if (g_audio) ndspExit();
    C2D_Fini(); C3D_Fini();
    romfsExit(); gfxExit();
    return 0;
}
