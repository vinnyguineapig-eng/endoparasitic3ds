ENDOPARASITIC - NINTENDO 3DS PORT (fan port, with the developer's permission)
================================================================================
A native C rewrite of the game for the 3DS (works on old 3DS / 3DS XL). Not an emulator and not
a streaming app: the game logic is rewritten in C, using the original art, levels and sounds
(converted and shrunk to fit the 3DS).

BUILD (you need devkitPro; I could not compile it myself - see STATUS below)
  1. Install devkitPro (https://devkitpro.org), then in its terminal:
         pacman -S 3ds-dev
  2. Open a devkitPro terminal in THIS folder and run:
         make
     -> produces endoparasitic3ds.3dsx (about 19 MB, the game data is inside it)
  3. Copy endoparasitic3ds.3dsx to  /3ds/  on the SD card and open it from the Homebrew Launcher.

CONTROLS
  Menu:     D-pad Up/Down to pick a level, A to start
  A         left click: hold + slide the touchpad to grab the ground and drag yourself along
            (with the gun out: shoot)
  B         right click: take the revolver out / put it away
  Y         F: reload the revolver
  X         Q (reserved - not used yet)         Circle pad: scroll (reserved - not used yet)
  Bottom screen = black touchpad (backlight off). Slide your finger to move the hand.
  SELECT    back to the menu        L / R   previous / next level        START   quit

WHAT IS IN THE GAME
  - All 28 playable levels, converted from the original scenes (floors, walls, props, doors, pickups,
    enemies), with the original art. Cutscene-only scenes are left out.
  - The original movement: you pull yourself along with your hand, limited by your arm's reach (127px),
    with the same drag cap and slide-out as the original code.
  - Revolver with a 6-round drum, reloading, ammo and health pickups, medkit healing, level exits,
    sliding doors, health and ammo display.
  - Zombies and rats that notice you (sight + line of sight), chase you and hurt you; they take
    damage from the original health values.
  - Sound effects and music from the original, compressed (16 kHz mono).
  - Darkness with a light around the player, as an approximation of the game's lighting.

NOT DONE / DIFFERENT FROM THE ORIGINAL (be aware)
  - Not every enemy and gadget is implemented: only zombies and rats are active. Other enemies
    (monkeys, bosses, etc.), shotgun, crossbow, flare gun, buttons, notes, saving, cutscenes,
    dialogue and the original UI/menus are not ported yet. They appear as scenery.
  - Characters are drawn in their rest pose (no limb animation). The arm is a simple line + hand.
  - Lighting/shadows are a simple fixed darkness circle, not the real dynamic shadows.
  - Walls are drawn flat (the original's pseudo-3D wall layers are not reproduced).
  - Inventory/dragging items and the revolver loading mini-game are replaced by buttons (Y reload).

CONTROLS RECAP (the 3DS build now has the same mechanics as the browser preview)
  Hand: slide the touchpad (relative movement, like the original's captured mouse), reach limited by arm length.
  A hold + slide = grab the ground and drag yourself. B with the hand on your holster = revolver out / away.
  Circle pad up = open inventory; in the inventory, up again = spin the chamber, down = close.
  Inventory: A on a bullet (bottom row), slide it onto an empty chamber slot, let go = loaded. A on a spent
  shell in the chamber, pull it out, let go = discarded. A on a syringe (left), slide it over the parasite = heal 50.
  Pickups: bullets go to your pool (max 6 carried), syringes are carried (max 3), the revolver goes on your holster.
  X and Y are Q and F as you set them; they have no action in the original game.
  The arm bends at the elbow (same maths as the original), and the camera is locked to you so the dark
  circle never lags.

STATUS - READ THIS
  I (Claude) wrote and tested the game logic and data pipeline on a PC: all 28 levels load and run
  without errors under a memory checker, and combat/movement/menu were verified with a software
  renderer. But I had no 3DS toolchain, so the 3DS-specific layer (source/main.c: graphics, touch,
  audio) was only type-checked against stand-in headers I wrote from memory. It has NEVER been
  compiled with the real libraries or run on a console. Expect that you may hit a build error or a
  visual glitch (for example: tints, texture orientation, speed on an old 3DS). If so, send me the
  error text or describe what you see and I will fix it.

IF TEXTURES LOOK WRONG ON YOUR 3DS
  Create  /3ds/endoparasitic.cfg  on the SD card (plain text) and try, one at a time:
      flip_v=1     everything is upside-down
      tint=0       colours look wrong, or sprites are missing/invisible
      tint=2       alternative tinting
  Texture checks done on the PC: no texture exceeds the 3DS limit (1024x1024), every sprite's source
  area lies inside its texture, and the heaviest level needs 3.2 MB of texture memory. What I could not
  check is how the real GPU draws them.

FOLDERS
  source/   C code: engine.c/.h (game, portable) and main.c (3DS layer)
  romfs/    converted game data: levels, textures (3DS format), sound, music
  tools/    Python converters that made romfs/ from the game's .pck (run:
            ENDO_PCK=path/to/Endoparasitic.pck python3 export.py <levels...>; needs Pillow + numpy + ffmpeg)
