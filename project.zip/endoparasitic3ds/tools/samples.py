import struct,pickle,re,collections
ENTS=pickle.load(open('/home/claude/w/ents.pkl','rb'));_f=open('/home/claude/w/Endoparasitic.pck','rb')
def read(p,o,s):_f.seek(o);return _f.read(s)
def parse_sample(d):
    i=d.find(b'resource_local_to_scene');cnt=struct.unpack('<I',d[i-8:i-4])[0];pos=i-4;names=[]
    for _ in range(cnt):
        l=struct.unpack('<I',d[pos:pos+4])[0];names.append(d[pos+4:pos+4+l-1].decode());pos+=4+l
    j=d.find(b'\x1f\x00\x00\x00\x00',0) if False else None
    # data array: entry (name 'data', type 31)
    di=names.index('data');pat=struct.pack('<II',di,31);k=d.find(pat,pos)
    L=struct.unpack('<I',d[k+8:k+12])[0];data=d[k+12:k+12+L];q=k+12+((L+3)&~3)
    props={'format':0,'mix_rate':44100,'stereo':False,'loop_mode':0}
    # remaining entries until trailer
    while q+8<=len(d)-4:
        ni,ty=struct.unpack('<II',d[q:q+8]);q+=8
        if ni>=len(names):break
        if ty==3:v=struct.unpack('<i',d[q:q+4])[0];q+=4
        elif ty==2:v=bool(struct.unpack('<I',d[q:q+4])[0]);q+=4
        elif ty==4:v=struct.unpack('<f',d[q:q+4])[0];q+=4
        else:break
        props[names[ni]]=v
    return data,props
if __name__=='__main__':
    c=collections.Counter();tot=0;bad=0
    for p,o,s in ENTS:
        if p.endswith('.sample'):
            try:
                data,pr=parse_sample(read(p,o,s));c[(pr['format'],pr['stereo'],pr['mix_rate'])]+=1;tot+=len(data)
            except Exception as e:bad+=1
    print(c.most_common(12),'bytes',tot/1e6,'bad',bad)
