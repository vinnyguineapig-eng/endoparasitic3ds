import sys,os,struct,math,shutil
import numpy as np
sys.path.insert(0,'/home/claude/port')
import convert as C, gd
from gd import *
OUT='/home/claude/port/romfs'
def pow2(n):
    p=8
    while p<n:p*=2
    return p
def swizzle_rgba4444(im):
    a=np.array(im,dtype=np.uint8);h,w=a.shape[:2]
    th,tw=pow2(h),pow2(w)
    pad=np.zeros((th,tw,4),np.uint8);pad[:h,:w]=a
    pad=pad[::-1]                      # PICA200 textures are stored bottom-up
    q=((pad.astype(np.uint16)*15+127)//255)
    px=(q[...,0]<<12)|(q[...,1]<<8)|(q[...,2]<<4)|q[...,3]
    # morton order inside each 8x8 tile
    idx=np.zeros((8,8),np.int64)
    for y in range(8):
        for x in range(8):
            m=0
            for b in range(3):m|=((x>>b)&1)<<(2*b)|((y>>b)&1)<<(2*b+1)
            idx[y,x]=m
    t=px.reshape(th//8,8,tw//8,8).transpose(0,2,1,3).reshape(-1,64)   # tiles, [y][x]
    out=np.zeros_like(t)
    flat_idx=idx.reshape(64)
    out[:,flat_idx]=t
    return out.astype('<u2').tobytes(),(w,h,tw,th)
def f4(*v):return struct.pack('<%df'%len(v),*v)
def rgba(c):return bytes(max(0,min(255,int(round(x*255)))) for x in c)
def inv(m):
    a,b,c,d,e,f=m;det=a*d-b*c;ia,ib,ic,id_=d/det,-b/det,-c/det,a/det
    return (ia,ib,ic,id_,-(ia*e+ic*f),-(ib*e+id_*f))
def spr_rec(s,rig=None):
    tid,sx,sy,sw,sh,tf,ox,oy,col,z,fl,owner=s
    if rig and owner in rig and owner!=100:tf=mul(inv(rig[owner]),tf)
    return struct.pack('<5HBB',tid,sx,sy,sw,sh,fl,0)+f4(*tf)+f4(ox,oy)+rgba(col)+struct.pack('<hh',max(-32000,min(32000,z)),owner)
def col_rec(c):
    kind,owner,m,hx,hy=c
    return struct.pack('<Bxh',kind,owner)+f4(*m)+f4(hx,hy)
def export_level(L,treg,name):
    os.makedirs(OUT+'/levels',exist_ok=True)
    b=bytearray(b'EL03')
    used=sorted({t[0] for t in L.tiles}|{s[0] for s in L.sprites}|{s[0] for m in L.models.values() for s in m[0].sprites})
    b+=struct.pack('<I',len(used))+b''.join(struct.pack('<H',u) for u in used)
    if len(used)%2:b+=b'\0\0'
    models=sorted(L.models.items(),key=lambda kv:kv[1][1])
    mspr=[];mcol=[];mrec=[];rigs={};s_owner_model={}
    for nm,(sub,idx) in models:
        for s_ in sub.sprites:s_owner_model[id(s_)]=nm
        rigs[nm]=getattr(sub,'rig',None)
        mrec.append((nm,len(mspr),len(sub.sprites),len(mcol),len(sub.cols),getattr(sub,'model_rad',8.0)))
        mspr+=sub.sprites;mcol+=sub.cols
    b+=struct.pack('<7I',len(L.tiles),len(L.sprites),len(L.cols),len(L.ents),len(models),len(mspr),len(mcol))
    for t in L.tiles:
        texid,sx,sy,sw,sh,wx,wy,col,z,fl=t
        b+=struct.pack('<5HBB',texid,sx,sy,sw,sh,fl,0)+f4(wx,wy)+rgba(col)+struct.pack('<hh',max(-32000,min(32000,z)),0)
    for s in L.sprites:b+=spr_rec(s)
    for c in L.cols:b+=col_rec(c)
    for e in L.ents:
        nm,tf,mi,z,pr=e
        hp=num(pr.get('health',pr.get('ammo_amount','4')),4);sp=num(pr.get('move_speed','80'),80);dm=num(pr.get('damage','30'),30);sr=num(pr.get('sight_range','450'),450)
        b+=struct.pack('<Hh',mi,max(-32000,min(32000,z)))+f4(*tf)+f4(hp,sp,dm,sr)
    for nm,fs,ns,fc,nc,rad in mrec:
        b+=nm.encode()[:23].ljust(24,b'\0')+struct.pack('<4If',fs,ns,fc,nc,rad)
    for s in mspr:b+=spr_rec(s,rigs.get(s_owner_model[id(s)]))
    for c in mcol:b+=col_rec(c)
    open(OUT+'/levels/%s.lvl'%name,'wb').write(b)
    return len(b)
def export_textures(treg):
    os.makedirs(OUT+'/tex',exist_ok=True);tbl=bytearray(struct.pack('<I',len(treg.paths)));tot=0
    for i,p in enumerate(treg.paths):
        im=gd.load_image(p)
        if max(im.size)>1024:
            s=1024/max(im.size);im=im.resize((max(1,int(im.size[0]*s)),max(1,int(im.size[1]*s))))
        data,(w,h,tw,th)=swizzle_rgba4444(im)
        open(OUT+'/tex/%04d.bin'%i,'wb').write(data);tbl+=struct.pack('<4H',w,h,tw,th);tot+=len(data)
    open(OUT+'/tex.tbl','wb').write(tbl);return tot
if __name__=='__main__':
    levels=[l for l in sys.argv[1:]]
    treg=C.TexReg();done=[];treg.get('res://art_assets/white_sq.png')   # id 0 = white
    for lv in levels:
        L=C.Level(treg)
        C.flatten(L,'res://levels/%s.tscn'%lv,dict(tf=(1,0,0,1,0,0),z=0,mod=(1,1,1,1),owner=-1,static=False),{})
        n=lv.split('/')[-1];sz=export_level(L,treg,n);done.append(n)
        print(n,'tiles',len(L.tiles),'spr',len(L.sprites),'col',len(L.cols),'ents',len(L.ents),'bytes',sz)
    import build_ui,json
    _ui=build_ui.build(treg);json.dump(_ui,open(OUT+'/ui.json','w'));open(OUT+'/ui.txt','w').write(build_ui.to_txt(_ui))
    tot=export_textures(treg);print('textures',len(treg.paths),'bytes',tot)
    MUS=lambda lv:('labs_loop' if lv.split('/')[0] in('unarmed_levels','revolver_levels') else 'labs_track' if lv.split('/')[0] in('shotgun_levels','flare_levels') else 'maint_loop' if lv.startswith('maintenance') else 'reception_track')
    open(OUT+'/levels.txt','w').write('\n'.join('%s|%s'%(lv.split('/')[-1],MUS(lv)) for lv in levels))
