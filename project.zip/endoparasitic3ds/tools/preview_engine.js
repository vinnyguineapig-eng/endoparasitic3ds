'use strict';
// JavaScript port of engine.c (same logic) for the browser preview.
const VW=400,VH=240,VS0=0.5,VSI=0.4,UPPER=51.584,LOWER=75.2281,TICK=1/60,ARM=UPPER+LOWER,MINHAND=30,PR=37.4672,TK=1.8,MAXD=20,DRUM=6,FONT_ID=4094,VIG_ID=4095;
const K={PLAYER:1,ZOMBIE:2,RAT:3,MONKEY:4,BULLETS:6,HEALTH:7,GUN:8,EXIT:9,DOOR:10,OTHER:11};
const FC="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-:./>";
const FR=["01110,10001,10001,11111,10001,10001,10001","11110,10001,10001,11110,10001,10001,11110","01110,10001,10000,10000,10000,10001,01110","11110,10001,10001,10001,10001,10001,11110","11111,10000,10000,11110,10000,10000,11111","11111,10000,10000,11110,10000,10000,10000","01110,10001,10000,10111,10001,10001,01111","10001,10001,10001,11111,10001,10001,10001","01110,00100,00100,00100,00100,00100,01110","00111,00010,00010,00010,00010,10010,01100","10001,10010,10100,11000,10100,10010,10001","10000,10000,10000,10000,10000,10000,11111","10001,11011,10101,10101,10001,10001,10001","10001,11001,10101,10011,10001,10001,10001","01110,10001,10001,10001,10001,10001,01110","11110,10001,10001,11110,10000,10000,10000","01110,10001,10001,10001,10101,10010,01101","11110,10001,10001,11110,10100,10010,10001","01111,10000,10000,01110,00001,00001,11110","11111,00100,00100,00100,00100,00100,00100","10001,10001,10001,10001,10001,10001,01110","10001,10001,10001,10001,10001,01010,00100","10001,10001,10001,10101,10101,11011,10001","10001,10001,01010,00100,01010,10001,10001","10001,10001,01010,00100,00100,00100,00100","11111,00001,00010,00100,01000,10000,11111","01110,10001,10011,10101,11001,10001,01110","00100,01100,00100,00100,00100,00100,01110","01110,10001,00001,00010,00100,01000,11111","11110,00001,00001,01110,00001,00001,11110","00010,00110,01010,10010,11111,00010,00010","11111,10000,11110,00001,00001,10001,01110","00110,01000,10000,11110,10001,10001,01110","11111,00001,00010,00100,01000,01000,01000","01110,10001,10001,01110,10001,10001,01110","01110,10001,10001,01111,00001,00010,01100","00000,00000,00000,11111,00000,00000,00000","00000,00100,00000,00000,00000,00100,00000","00000,00000,00000,00000,00000,01100,01100","00001,00010,00010,00100,01000,01000,10000","10000,01000,00100,00010,00100,01000,10000"];
const cl=(v,a,b)=>v<a?a:v>b?b:v, hyp=Math.hypot, mmul=(p,q)=>[p[0]*q[0]+p[2]*q[1],p[1]*q[0]+p[3]*q[1],p[0]*q[2]+p[2]*q[3],p[1]*q[2]+p[3]*q[3],p[0]*q[4]+p[2]*q[5]+p[4],p[1]*q[4]+p[3]*q[5]+p[5]];
const mort=(x,y)=>{let m=0;for(let b=0;b<3;b++)m|=((x>>b)&1)<<(2*b)|((y>>b)&1)<<(2*b+1);return m;};
function Engine(plat,fs){
  const text8=new TextDecoder();let names=[],music=[],texinfo=[],cur=-1,curMusic='',sfxn=0,inMenu=true,sel=0,top=0,disp=[];
  const pend={a:0,b:0,y:0,x:0,sc:0,dx:0,dy:0};let L=null,P={},cam={x:0,y:0},tracer={t:0},acc=0,loaded=new Set(),UI=null,VS=VS0;
  const noIn={};
  function init(){
    for(const ln of text8.decode(fs('levels.txt')).split('\n')){if(!ln)continue;const[a,b]=ln.split('|');names.push(a);music.push(b||'');}
    const t=fs('tex.tbl'),dv=new DataView(t.buffer,t.byteOffset,t.byteLength),n=dv.getUint32(0,true);
    for(let i=0;i<n;i++)texinfo.push({w:dv.getUint16(4+i*8,true),h:dv.getUint16(6+i*8,true),tw:dv.getUint16(8+i*8,true),th:dv.getUint16(10+i*8,true)});
    // procedural textures: darkness is drawn by the platform; font atlas 64x64 (u16 RGBA4444, plain row-major here)
    const f=new Uint16Array(64*64);
    for(let i=0;i<FC.length;i++){const gx=(i%8)*8,gy=((i/8)|0)*8,rows=FR[i].split(',');for(let r=0;r<7;r++)for(let c=0;c<5;c++)if(rows[r][c]==='1')f[(gy+r)*64+gx+c]=0xFFFF;}
    plat.texCreate(FONT_ID,64,64,64,64,f,true);
    mkTex(0);loaded.add(0);try{UI=JSON.parse(text8.decode(fs('ui.json')));}catch(e){UI=null;}
    names.forEach((s,i)=>{let o=String(i+1).padStart(2,'0')+' ';for(let k=0;k<s.length&&o.length<38;k++){let ch=s[k];const up=c=>c>='A'&&c<='Z',lo=c=>c>='a'&&c<='z';if(k>0&&up(ch)&&(lo(s[k-1])||(up(s[k-1])&&lo(s[k+1]||''))))o+=' ';o+=ch.toUpperCase();}disp.push(o);});
    inMenu=true;sel=0;plat.music('labs_track');return 0;
  }
  function mkTex(id){const t=texinfo[id],d=fs('tex/'+String(id).padStart(4,'0')+'.bin');if(!d)return;
    plat.texCreate(id,t.w,t.h,t.tw,t.th,new Uint16Array(d.buffer.slice(d.byteOffset,d.byteOffset+d.byteLength)),false);}
  function freeLevel(){if(!L)return;for(const id of L.used)if(id!==0&&loaded.has(id)){plat.texFree(id);loaded.delete(id);}L=null;}
  const kindOf=n=>n==='Player'?1:n==='Zombie'?2:n==='Rat'?3:n==='Monkey'?4:n==='RevolverBullets'?6:n==='HealthPickup'?7:n==='RevolverPickup'?8:n==='LevelExit'?9:n.endsWith('Door')?10:11;
  function loadLevel(idx){
    if(idx<0)idx=names.length-1;if(idx>=names.length)idx=0;freeLevel();cur=idx;inMenu=false;
    const b=fs('levels/'+names[idx]+'.lvl');if(!b)return -1;const dv=new DataView(b.buffer,b.byteOffset,b.byteLength);let p=4;
    const nu=dv.getUint32(p,true);p+=4;const used=[];for(let i=0;i<nu;i++)used.push(dv.getUint16(p+i*2,true));p+=nu*2+(nu&1?2:0);
    const c=[];for(let i=0;i<7;i++)c.push(dv.getUint32(p+i*4,true));p+=28;
    const f=(o)=>dv.getFloat32(p+o,true),u16=o=>dv.getUint16(p+o,true),i16=o=>dv.getInt16(p+o,true),u8=o=>dv.getUint8(p+o);
    const tiles=[],spr=[],col=[],er=[],model=[],mspr=[],mcol=[];
    const rS=()=>{const s={tex:u16(0),sx:u16(2),sy:u16(4),sw:u16(6),sh:u16(8),fl:u8(10),m:[f(12),f(16),f(20),f(24),f(28),f(32)],ox:f(36),oy:f(40),c:[u8(44),u8(45),u8(46),u8(47)],z:i16(48),owner:i16(50)};p+=52;return s;};
    const rC=()=>{const o={kind:u8(0),owner:i16(2),m:[f(4),f(8),f(12),f(16),f(20),f(24)],hx:f(28),hy:f(32)};p+=36;return o;};
    for(let i=0;i<c[0];i++){tiles.push({tex:u16(0),sx:u16(2),sy:u16(4),sw:u16(6),sh:u16(8),fl:u8(10),x:f(12),y:f(16),c:[u8(20),u8(21),u8(22),u8(23)],z:i16(24)});p+=28;}
    for(let i=0;i<c[1];i++)spr.push(rS());for(let i=0;i<c[2];i++)col.push(rC());
    for(let i=0;i<c[3];i++){er.push({model:u16(0),z:i16(2),m:[f(4),f(8),f(12),f(16),f(20),f(24)],hp:f(28),speed:f(32),dmg:f(36),sight:f(40)});p+=44;}
    for(let i=0;i<c[4];i++){let nm='';for(let k=0;k<24&&u8(k);k++)nm+=String.fromCharCode(u8(k));model.push({name:nm,fs:dv.getUint32(p+24,true),ns:dv.getUint32(p+28,true),fc:dv.getUint32(p+32,true),nc:dv.getUint32(p+36,true),rad:f(40)});p+=44;}
    for(let i=0;i<c[5];i++)mspr.push(rS());for(let i=0;i<c[6];i++)mcol.push(rC());
    L={tiles,spr,col,model,mspr,mcol,used,ent:[],solid:new Set(),draw:[]};
    const need=new Set(used);if(UI)for(const k in UI){const v=UI[k];if(v&&v.tex!==undefined)need.add(v.tex);}
    L.used=[...need];for(const id of need)if(!loaded.has(id)){mkTex(id);loaded.add(id);}
    P={x:0,y:0,hx:0,hy:0,gx:0,gy:0,dragging:0,hp:100,gun:0,out:0,ammo:0,syr:0,slots:[0,0,0,0,0,0],ready:0,rot:0,inv:0,cur:{x:0,y:0},grab:null,dead:0,hurt:0,face:0,sx:0,sy:0,mv:[],ent:-1};
    er.forEach((r,i)=>{const m=model[r.model],e={name:m.name,kind:kindOf(m.name),model:r.model,z:r.z,x:r.m[4],y:r.m[5],rot:Math.atan2(r.m[1],r.m[0]),sx:hyp(r.m[0],r.m[1]),sy:hyp(r.m[2],r.m[3]),hp:r.hp,speed:r.speed,dmg:r.dmg,sight:r.sight,alive:1,aware:0,cd:0,wind:0,stun:0,taken:0,open:0};
      if(r.m[0]*r.m[3]-r.m[1]*r.m[2]<0)e.sy=-e.sy;e.r=e.kind===2?24:e.kind===3?14:e.kind===4?28:(m.rad>8?m.rad:24);
      if(e.kind===1){P.ent=i;P.x=e.x;P.y=e.y;P.face=e.rot;}L.ent.push(e);});
    if(P.ent<0){const e=L.ent.find(e=>e.kind===9);if(e){P.x=e.x;P.y=e.y;}}
    cam.x=P.x;cam.y=P.y;VS=VS0;
    for(const t of tiles)if(t.fl&8){const x0=Math.floor(t.x/32+0.01),y0=Math.floor(t.y/32+0.01),w=((t.sw+31)/32)|0,h=((t.sh+31)/32)|0;for(let yy=0;yy<h;yy++)for(let xx=0;xx<w;xx++)L.solid.add((x0+xx+4096)*8192+(y0+yy+4096));}
    tiles.forEach((t,i)=>L.draw.push([t.z,0,i]));spr.forEach((s,i)=>L.draw.push([s.z,1,i]));
    L.ent.forEach((e,i)=>{const m=model[e.model];let z=e.z+(m.ns?mspr[m.fs].z:0);if(e.kind===1)z=30000;L.draw.push([z,2,i]);});
    L.draw.sort((a,b)=>a[0]-b[0]||a[1]-b[1]||a[2]-b[2]);
    tracer.t=0;acc=0;if(curMusic!==music[idx]){curMusic=music[idx];plat.music(curMusic||null);}return 0;
  }
  const hget=(x,y)=>L.solid.has((x+4096)*8192+(y+4096));
  const active=c=>!(c.owner>=0&&c.owner<L.ent.length&&L.ent[c.owner].kind===10&&L.ent[c.owner].open>0.5);
  function pushOut(o,r){let hit=0;
    for(let it=0;it<3;it++){
      const x0=Math.floor((o.x-r)/32),x1=Math.floor((o.x+r)/32),y0=Math.floor((o.y-r)/32),y1=Math.floor((o.y+r)/32);
      for(let gy=y0;gy<=y1;gy++)for(let gx=x0;gx<=x1;gx++){if(!hget(gx,gy))continue;
        const bx0=gx*32,by0=gy*32,bx1=bx0+32,by1=by0+32,nx=cl(o.x,bx0,bx1),ny=cl(o.y,by0,by1),dx=o.x-nx,dy=o.y-ny,d2=dx*dx+dy*dy;
        if(d2<r*r){if(d2>1e-6){const d=Math.sqrt(d2);o.x+=dx/d*(r-d);o.y+=dy/d*(r-d);}
          else{const l=o.x-bx0,rr=bx1-o.x,t=o.y-by0,bb=by1-o.y,m=Math.min(l,rr,t,bb);if(m===l)o.x=bx0-r;else if(m===rr)o.x=bx1+r;else if(m===t)o.y=by0-r;else o.y=by1+r;}hit=1;}}
      for(const c of L.col){if(!active(c))continue;const[a,b,cc,d,e,f]=c.m;
        if(c.kind===1){const rad=c.hx*Math.max(hyp(a,b),hyp(cc,d)),dx=o.x-e,dy=o.y-f,dist=hyp(dx,dy);if(dist<rad+r&&dist>1e-4){o.x=e+dx/dist*(rad+r);o.y=f+dy/dist*(rad+r);hit=1;}continue;}
        const det=a*d-b*cc;if(Math.abs(det)<1e-9)continue;const ix=o.x-e,iy=o.y-f,lx=(d*ix-cc*iy)/det,ly=(-b*ix+a*iy)/det,sx=hyp(a,b),sy=hyp(cc,d);
        if(Math.abs(o.x-e)>c.hx*sx+c.hy*sy+r+2||Math.abs(o.y-f)>c.hx*sx+c.hy*sy+r+2)continue;
        const nx=cl(lx,-c.hx,c.hx),ny=cl(ly,-c.hy,c.hy),dx=(lx-nx)*sx,dy=(ly-ny)*sy,d2=dx*dx+dy*dy;
        if(d2<r*r){let wx,wy;
          if(d2>1e-6){const dd=Math.sqrt(d2),push=r-dd;let ux=lx-nx,uy=ly-ny;const ul=hyp(ux,uy);ux/=ul;uy/=ul;wx=a*ux+cc*uy;wy=b*ux+d*uy;const wl=hyp(wx,wy);wx/=wl;wy/=wl;o.x+=wx*push;o.y+=wy*push;}
          else{const px=c.hx-Math.abs(lx),py=c.hy-Math.abs(ly);let ux=0,uy=0;if(px*sx<py*sy)ux=lx<0?-1:1;else uy=ly<0?-1:1;wx=a*ux+cc*uy;wy=b*ux+d*uy;const wl=hyp(wx,wy);wx/=wl;wy/=wl;const mv=Math.min(px*sx,py*sy)+r;o.x+=wx*mv;o.y+=wy*mv;}hit=1;}}}
    return hit;}
  function rayBlocked(x0,y0,x1,y1){const dx=x1-x0,dy=y1-y0,len=hyp(dx,dy),n=((len/8)|0)+1;
    for(let i=1;i<=n;i++){const t=i/n,x=x0+dx*t,y=y0+dy*t;if(hget(Math.floor(x/32),Math.floor(y/32)))return 1;
      for(const c of L.col){if(!active(c)||c.kind===1)continue;const[a,b,cc,d,e,f]=c.m,det=a*d-b*cc;if(Math.abs(det)<1e-9)continue;const ix=x-e,iy=y-f,lx=(d*ix-cc*iy)/det,ly=(-b*ix+a*iy)/det;if(Math.abs(lx)<c.hx&&Math.abs(ly)<c.hy)return 1;}}return 0;}
  function rayWall(x,y,dx,dy,mx){for(let t=8;t<mx;t+=8)if(rayBlocked(x+dx*(t-8),y+dy*(t-8),x+dx*t,y+dy*t))return t;return mx;}
  const alert=(x,y,r)=>{for(const e of L.ent)if(e.alive&&(e.kind===2||e.kind===3)&&hyp(e.x-x,e.y-y)<r)e.aware=1;};
  function shoot(){
    const can=P.slots[P.ready]===1;const slot=P.ready;P.ready=(P.ready+1)%6;P.rot=P.ready*Math.PI*2/6;
    if(!can){plat.sfx('dry_fire');return;}
    P.slots[slot]=2;plat.sfx('revolver_shot'+(1+sfxn++%3));
    let dx=P.hx,dy=P.hy;const l=hyp(dx,dy);if(l<1){dx=Math.cos(P.face);dy=Math.sin(P.face);}else{dx/=l;dy/=l;}
    const ox=P.x+dx*30,oy=P.y+dy*30;let best=rayWall(ox,oy,dx,dy,1100),hit=-1;
    L.ent.forEach((e,i)=>{if(!e.alive||!(e.kind===2||e.kind===3||e.kind===4))return;const vx=e.x-ox,vy=e.y-oy,t=vx*dx+vy*dy;if(t<0||t>best)return;const px=ox+dx*t-e.x,py=oy+dy*t-e.y;if(px*px+py*py<e.r*e.r){best=t;hit=i;}});
    if(hit>=0){const e=L.ent[hit];e.hp-=1;e.stun=6;e.aware=1;if(e.hp<=0){e.alive=0;plat.sfx('SpikrDeath-001');}else plat.sfx((sfxn&1)?'SpikrHurt-001':'SpikrHurt-002');}
    tracer={x0:ox,y0:oy,x1:ox+dx*best,y1:oy+dy*best,t:5};alert(P.x,P.y,700);P.x-=dx*5;P.y-=dy*5;pushOut(P,PR);}
  function hurt(d){if(P.dead>0)return;P.hp-=d;P.hurt=12;if(P.hp<=0){P.hp=0;P.dead=120;plat.sfx('player_die');}else plat.sfx((sfxn++&1)?'player_hurt':'player_hurt2');}
  const slotPos=i=>{const r=P.rot,c=Math.cos(r),s=Math.sin(r),m=mmul(UI.pivot,[c,s,-s,c,0,0]);const q=UI.slots[i];return [m[0]*q[0]+m[2]*q[1]+m[4],m[1]*q[0]+m[3]*q[1]+m[5]];};
  const bulletPos=i=>{const t=UI.ammoTf,x=Math.floor(i/2)*50,y=(i%2===0)?-140:0;return [t[0]*(x+27.5)+t[4],t[3]*(y-66.5)+t[5]];};
  const syrPos=i=>[UI.syrTf[4]+i*20,UI.syrTf[5]];
  const paraY=()=>UI.parasiteStartY+(UI.parasiteEndY-UI.parasiteStartY)*(1-P.hp/100);
  function openInv(){if(P.inv)return;P.inv=1;P.cur={x:0,y:0};P.grab=null;P.dragging=0;plat.sfx('click');}
  function closeInv(){if(!P.inv)return;P.inv=0;P.grab=null;let bd=1e9,bi=P.ready;for(let i=0;i<6;i++){const p=slotPos(i),d=(p[0]-UI.next[4])**2+(p[1]-UI.next[5])**2;if(d<bd){bd=d;bi=i;}}P.ready=bi;P.rot=P.ready*Math.PI*2/6;plat.sfx('click');}
  function invTick(inp,dx,dy,first){
    if(inp.aim){P.cur.x=cl((inp.aim.x-VW/2)/VSI,-400,400);P.cur.y=cl((inp.aim.y-VH/2)/VSI,-300,300);}
    else if(first){P.cur.x=cl(P.cur.x+dx*2.5,-400,400);P.cur.y=cl(P.cur.y+dy*2.5,-300,300);}
    const c=P.cur;
    if(inp.a_pressed&&first&&!P.grab){
      for(let i=0;i<P.syr;i++){const p=syrPos(i);if(Math.abs(c.x-p[0])<=18&&c.y>=p[1]-108&&c.y<=p[1]+58){P.grab={t:'syr'};plat.sfx('grab_thing');return;}}
      for(let i=0;i<P.ammo;i++){const p=bulletPos(i);if(Math.abs(c.x-p[0])<=27*0.8+8&&Math.abs(c.y-p[1])<=67*0.8+8){P.grab={t:'bullet'};plat.sfx('grab_thing');return;}}
      for(let i=0;i<6;i++){if(P.slots[i]!==2)continue;const p=slotPos(i);if(hyp(c.x-p[0],c.y-p[1])<=UI.slotR){P.slots[i]=0;P.grab={t:'shell'};plat.sfx('grab_thing');return;}}
    }
    if(P.grab){
      if(P.grab.t==='syr'){const ph=UI.parasiteHit,py=paraY()+(ph[5]-UI.parasite.tf[5]),px=ph[4];
        if(hyp(c.x-px,c.y-py)<45){P.syr--;P.hp=Math.min(100,P.hp+50);P.grab=null;plat.sfx('grab_thing');return;}}
      if(!inp.a_held){
        if(P.grab.t==='bullet'){const d=UI.dropTf,inDrop=Math.abs(c.x-d[4])<16*d[0]&&Math.abs(c.y-d[5])<16*d[3];let done=false;
          if(inDrop){P.ammo--;done=true;}
          else for(let i=0;i<6&&!done;i++){const p=slotPos(i);if(hyp(c.x-p[0],c.y-p[1])<=UI.slotR&&P.slots[i]===0){P.slots[i]=1;P.ammo--;plat.sfx('revolver_return_bullet');done=true;}}}
        P.grab=null;}}}
  function tickPlayer(inp,dx,dy,first){
    if(P.dead>0){if(--P.dead===0)loadLevel(cur);return;}
    if(first){
      if(inp.scroll>0){if(!P.inv)openInv();else{P.rot+=10*Math.PI/180;plat.sfx('slide_step');}}
      else if(inp.scroll<0&&P.inv)closeInv();
    }
    if(P.inv){invTick(inp,dx,dy,first);if(P.hurt>0)P.hurt--;return;}
    if(inp.b_pressed&&first&&P.gun){
      const c=Math.cos(P.face),s=Math.sin(P.face),hx=P.x+c*6-s*56,hy=P.y+s*6+c*56,hd=hyp(P.x+P.hx-hx,P.y+P.hy-hy);
      if(!P.out&&hd<30){P.out=1;plat.sfx('revolver_equip');}else if(P.out&&hd<40){P.out=0;plat.sfx('revolver_unequip');}}
    const gun=P.out&&P.gun,was=P.dragging;
    if(inp.a_held&&!gun){
      if(!was){P.dragging=1;P.gx=P.x+P.hx;P.gy=P.y+P.hy;P.mv=[];plat.sfx('grab_ground');}
      let mx=dx*TK,my=dy*TK;const l=hyp(mx,my);if(l>MAXD){mx*=MAXD/l;my*=MAXD/l;}
      const nx=P.x-mx,ny=P.y-my;if(hyp(nx-P.gx,ny-P.gy)>ARM){mx=my=0;}else{P.x=nx;P.y=ny;}
      if(P.mv.length<10)P.mv.push([mx,my]);else{P.mv.shift();P.mv.push([mx,my]);}
      if(mx*mx+my*my>16){P.st=(P.st||0)+1;if(P.st%14===0)plat.sfx(P.st&1?'slide_step':'slide_step2');}
      if(mx||my)P.face=Math.atan2(my,mx);pushOut(P,PR);P.hx=P.gx-P.x;P.hy=P.gy-P.y;
    }else{
      if(was){P.dragging=0;let sx=0,sy=0;for(const m of P.mv){sx+=m[0];sy+=m[1];}P.sx=-sx/20;P.sy=-sy/20;P.mv=[];}
      if(P.sx*P.sx+P.sy*P.sy>0.01){P.x+=P.sx;P.y+=P.sy;P.sx*=0.75;P.sy*=0.75;pushOut(P,PR);}
      if(inp.aim){let tx=(inp.aim.x-VW/2)/VS0,ty=(inp.aim.y-VH/2)/VS0;const tl=hyp(tx,ty);if(tl>ARM){tx*=ARM/tl;ty*=ARM/tl;}
        let mx=tx-P.hx,my=ty-P.hy;const ml=hyp(mx,my);if(ml>50){mx*=50/ml;my*=50/ml;}P.hx+=mx;P.hy+=my;}
      else{P.hx+=dx*TK;P.hy+=dy*TK;}
      const hl=hyp(P.hx,P.hy);if(hl>ARM){P.hx*=ARM/hl;P.hy*=ARM/hl;}
      if(hl>8)P.face=Math.atan2(P.hy,P.hx);if(gun&&inp.a_pressed&&first)shoot();}
    if(P.hurt>0)P.hurt--;}
  function tickEnemies(){
    for(let i=0;i<L.ent.length;i++){const e=L.ent[i];
      if(e.kind===10){const d=hyp(e.x-P.x,e.y-P.y),tg=d<190?1:0,po=e.open;e.open=cl(e.open+(tg>e.open?0.08:-0.04),0,1);if(po===0&&e.open>0)plat.sfx('SmallDoorOpen-001');if(po>0&&e.open===0)plat.sfx('SmallDoorClose-001');continue;}
      if(e.taken)continue;
      if(e.kind===6||e.kind===7||e.kind===8){const d=hyp(e.x-P.x,e.y-P.y),dh=hyp(e.x-(P.x+P.hx),e.y-(P.y+P.hy));
        if(d<PR+30||dh<34){if(e.kind===6){const n=Math.min(e.hp|0||3,6-P.ammo);if(n<=0)continue;P.ammo+=n;e.hp-=n;plat.sfx('pickup_revolver_bulelts');if(e.hp>0)continue;}else if(e.kind===7){if(P.syr>=3)continue;P.syr++;plat.sfx('grab_thing');}else{P.gun=1;plat.sfx('revolver_equip');}e.taken=1;}continue;}
      if(e.kind===9){if(hyp(e.x-P.x,e.y-P.y)<PR+60&&P.dead===0){loadLevel(cur+1);return;}continue;}
      if(e.kind!==2&&e.kind!==3)continue;if(!e.alive)continue;
      const dx=P.x-e.x,dy=P.y-e.y,d=hyp(dx,dy);
      if(!e.aware){if(d<e.sight&&P.dead===0&&!rayBlocked(e.x,e.y,P.x,P.y))e.aware=1;else continue;}
      if(e.stun>0){e.stun--;continue;}if(e.cd>0)e.cd--;
      const want=Math.atan2(dy,dx);let diff=want-e.rot;while(diff>3.14159)diff-=6.28318;while(diff<-3.14159)diff+=6.28318;
      const turn=140*0.0174533*TICK;if(Math.abs(diff)<turn)e.rot=want;else e.rot+=diff>0?turn:-turn;
      const reach=e.r+PR+8;
      if(e.wind>0){if(--e.wind===0&&d<reach+20)hurt(e.dmg|0);continue;}
      if(d<reach){if(e.cd===0){e.wind=18;e.cd=75;plat.sfx((sfxn++&1)?'SpikrSpectralZombieAttack-001':'SpikrSpectralZombieAttack-002');}continue;}
      const sp=e.speed*TICK,o={x:e.x+Math.cos(e.rot)*sp,y:e.y+Math.sin(e.rot)*sp};pushOut(o,e.r);
      const ddx=o.x-P.x,ddy=o.y-P.y,dd=hyp(ddx,ddy);if(dd<e.r+PR){o.x=P.x+ddx/dd*(e.r+PR);o.y=P.y+ddy/dd*(e.r+PR);}e.x=o.x;e.y=o.y;}}
  function update(inp,dt){
    if(inMenu){if(inp.menu_up&&sel>0)sel--;if(inp.menu_down&&sel<names.length-1)sel++;if(sel<top)top=sel;if(sel>=top+7)top=sel-6;if(inp.a_pressed){curMusic='';loadLevel(sel);}return;}
    if(inp.select_pressed){inMenu=true;sel=cur<0?0:cur;plat.music('labs_track');curMusic='';return;}
    if(cur<0)return;if(inp.next_level){loadLevel(cur+1);return;}if(inp.prev_level){loadLevel(cur-1);return;}
    acc=Math.min(acc+dt,0.1);let first=true,n=0,a2=acc;while(a2>=TICK){n++;a2-=TICK;}
    // keep one-shot presses and touch movement until a game tick actually consumes them (frames can be shorter than a tick)
    pend.a|=inp.a_pressed?1:0;pend.b|=inp.b_pressed?1:0;pend.y|=inp.y_pressed?1:0;pend.x|=inp.x_pressed?1:0;if(inp.scroll)pend.sc=inp.scroll;pend.dx+=inp.touch_dx||0;pend.dy+=inp.touch_dy||0;
    for(let s=0;s<n;s++){const ti=first?Object.assign({},inp,{a_pressed:pend.a,b_pressed:pend.b,y_pressed:pend.y,x_pressed:pend.x,scroll:pend.sc}):Object.assign({},inp,{a_pressed:0,b_pressed:0,y_pressed:0,x_pressed:0,scroll:0});
      tickPlayer(ti,first?pend.dx:0,first?pend.dy:0,first);if(first){pend.a=pend.b=pend.y=pend.x=pend.sc=0;pend.dx=pend.dy=0;}if(!L)return;tickEnemies();if(!L)return;first=false;if(tracer.t>0)tracer.t--;}
    acc=a2;cam.x=P.x;cam.y=P.y;VS=P.inv?VSI:VS0;}
  const D=(id,sx,sy,sw,sh,M,c)=>plat.draw(id,sx,sy,sw,sh,M,c);
  const col4=(c,ma,mr)=>[Math.min(255,c[0]*mr),Math.min(255,c[1]*mr),Math.min(255,c[2]*mr),Math.min(255,c[3]*ma)];
  function dSpr(s,par,ma,mr){const W=mmul(par,s.m),F=[(s.fl&1)?-1:1,0,0,(s.fl&2)?-1:1,s.ox+((s.fl&1)?s.sw:0),s.oy+((s.fl&2)?s.sh:0)];D(s.tex,s.sx,s.sy,s.sw,s.sh,mmul(W,F),col4(s.c,ma,mr));}
  const rect=(x,y,w,h,c)=>D(0,0,0,1,1,[w,0,0,h,x,y],c);
  function line(V,x0,y0,x1,y1,th,c){const dx=x1-x0,dy=y1-y0,l=hyp(dx,dy);if(l<0.5)return;const ux=dx/l,uy=dy/l;D(0,0,0,1,1,mmul(V,[ux*l,uy*l,-uy*th,ux*th,x0+uy*th*0.5,y0-ux*th*0.5]),[160,240,255,192]);}
  function text(s,x,y,sc,c){for(const ch of s){const i=FC.indexOf(ch);if(i>=0)D(FONT_ID,(i%8)*8,((i/8)|0)*8,6,8,[sc,0,0,sc,x,y],c);x+=6*sc;}}
  function drawMenu(){rect(0,0,VW,VH,[16,16,20,255]);text('ENDOPARASITIC',38,14,4,[240,144,144,255]);text('3DS PORT   WEB PREVIEW',92,52,2,[176,176,176,255]);
    for(let i=0;i<7;i++){const k=top+i;if(k>=names.length)break;const y=76+i*20;if(k===sel){rect(24,y-3,352,19,[48,64,112,255]);text('>',30,y,2,[255,208,64,255]);}text(disp[k],54,y,2,k===sel?[255,255,255,255]:[144,144,144,255]);}
    text('UP/DOWN: SELECT   A (CLICK): START',40,226,1,[128,128,128,255]);}
  function draw(){
    if(inMenu){drawMenu();return;}if(!L)return;
    VS=P.inv?VSI:VS0;const V=[VS,0,0,VS,Math.round(VW/2-cam.x*VS),Math.round(VH/2-cam.y*VS)];
    const vx0=cam.x-VW/2/VS-120,vx1=cam.x+VW/2/VS+120,vy0=cam.y-VH/2/VS-120,vy1=cam.y+VH/2/VS+120;
    for(const [,ty,ix] of L.draw){
      if(ty===0){const t=L.tiles[ix];if(t.x>vx1||t.y>vy1||t.x+t.sw<vx0||t.y+t.sh<vy0)continue;
        const W=t.sw,H=t.sh,F=(t.fl&4)?[0,(t.fl&2)?-1:1,(t.fl&1)?-1:1,0,(t.fl&1)?H:0,(t.fl&2)?W:0]:[(t.fl&1)?-1:1,0,0,(t.fl&2)?-1:1,(t.fl&1)?W:0,(t.fl&2)?H:0];
        D(t.tex,t.sx,t.sy,t.sw,t.sh,mmul(V,mmul([1,0,0,1,t.x,t.y],F)),t.c);
      }else if(ty===1){const s=L.spr[ix],r=hyp(s.sw,s.sh)*Math.max(hyp(s.m[0],s.m[1]),hyp(s.m[2],s.m[3]))+hyp(s.ox,s.oy);if(s.m[4]+r<vx0||s.m[4]-r>vx1||s.m[5]+r<vy0||s.m[5]-r>vy1)continue;dSpr(s,V,1,1);}
      else{const e=L.ent[ix],m=L.model[e.model];if(e.taken)continue;const cx=e.kind===1?P.x:e.x,cy=e.kind===1?P.y:e.y;if(cx<vx0-100||cx>vx1+100||cy<vy0-100||cy>vy1+100)continue;
        const rot=e.kind===1?P.face:e.rot,c=Math.cos(rot),sn=Math.sin(rot),E=[c*e.sx,sn*e.sx,-sn*e.sy,c*e.sy,cx,cy],EV=mmul(V,E);let ma=1,mr=1;
        if((e.kind===2||e.kind===3)&&!e.alive){ma=0.8;mr=0.35;}if(e.kind===1&&P.hurt>0)mr=1.8;
        if(e.kind===10){if(1-e.open<0.05)continue;for(let q=0;q<m.nc;q++){const cc=L.mcol[m.fc+q],a=mmul(E,cc.m);D(0,0,0,1,1,mmul(V,mmul(a,[cc.hx*2,0,0,cc.hy*2,-cc.hx,-cc.hy])),[72,64,64,255]);}continue;}
        let UP=EV,LO=EV,HA=EV;
        if(e.kind===1){const hx0=P.dragging?P.gx:P.x+P.hx,hy0=P.dragging?P.gy:P.y+P.hy,sx=hx0-P.x,sy=hy0-P.y,dist=cl(hyp(sx,sy),MINHAND,ARM),a0=Math.atan2(sy,sx);
          let B=0,Cc=0;if(dist<UPPER+LOWER){const lc=(a,b,c)=>(2*a*b===0)?0:Math.acos(cl((a*a+b*b-c*c)/(2*a*b),-1,1));const A=lc(LOWER,dist,UPPER),Bq=lc(dist,UPPER,LOWER)+Math.PI;B=Bq-Math.PI;Cc=Math.PI-A-Bq;}
          const sr=a0+B,er=Cc,um=[Math.cos(sr),Math.sin(sr),-Math.sin(sr),Math.cos(sr),P.x,P.y],lm=mmul(um,mmul([1,0,0,1,UPPER,0],[Math.cos(er),Math.sin(er),-Math.sin(er),Math.cos(er),0,0])),hm=mmul(lm,[1,0,0,1,LOWER,0]);
          UP=mmul(V,um);LO=mmul(V,lm);HA=mmul(V,hm);}
        for(let q=0;q<m.ns;q++){const s=L.mspr[m.fs+q];dSpr(s,s.owner===100?UP:s.owner===101?LO:s.owner===102?HA:EV,ma,mr);}
        if(e.kind===1){let hx=P.x+P.hx,hy=P.y+P.hy;if(P.dragging){hx=P.gx;hy=P.gy;}
          const hl=hyp(P.hx,P.hy),ux=hl>1?P.hx/hl:Math.cos(P.face),uy=hl>1?P.hy/hl:Math.sin(P.face);
          if(P.out&&P.gun)line2(V,hx,hy,hx+ux*34,hy+uy*34,10,[32,32,32,255]);
        }}}
    if(tracer.t>0)line(V,tracer.x0,tracer.y0,tracer.x1,tracer.y1,3);
    if(P.out&&P.gun){const hx=P.x+P.hx,hy=P.y+P.hy,l=hyp(P.hx,P.hy);if(l>1){const ux=P.hx/l,uy=P.hy/l,d=rayWall(hx,hy,ux,uy,500);D(0,0,0,1,1,[8,0,0,8,(hx+ux*d)*VS+V[4]-4,(hy+uy*d)*VS+V[5]-4],[224,48,48,255]);}}
    plat.dark((P.x-cam.x)*VS+VW/2,(P.y-cam.y)*VS+VH/2,210);
    if(P.inv&&UI)drawInv();else if(P.hp<=30&&P.hp>0){const pulse=0.5+0.5*Math.sin(performance_now()/180);rect(0,0,VW,6,[200,0,0,90*pulse+40]);rect(0,VH-6,VW,6,[200,0,0,90*pulse+40]);rect(0,6,6,VH-12,[200,0,0,90*pulse+40]);rect(VW-6,6,6,VH-12,[200,0,0,90*pulse+40]);}
    if(P.dead>0)rect(0,0,VW,VH,[16,0,0,144]);}
  const performance_now=()=>(typeof performance!=='undefined'?performance.now():Date.now());
  const W4=[255,255,255,255];
  function drawInv(){
    const UV=[VS,0,0,VS,VW/2,VH/2],ds=(it,tf,c)=>D(it.tex,it.sx,it.sy,it.sw,it.sh,mmul(UV,mmul(tf,[1,0,0,1,it.ox,it.oy])),c||it.c||W4),T=(x,y)=>[1,0,0,1,x,y];
    rect(0,0,VW,VH,[0,0,0,70]);
    ds(UI.brainBack,UI.brainBack.tf);ds(UI.brain,UI.brain.tf);
    const dy=paraY()-UI.parasite.tf[5];for(const k of['parasiteBack','parasite','legs']){const t=UI[k].tf.slice();t[5]+=dy;ds(UI[k],t);}
    const shownS=P.syr-(P.grab&&P.grab.t==='syr'?1:0);
    for(let i=0;i<shownS;i++){const p=syrPos(i);ds(UI.syrBase,T(p[0],p[1]));ds(UI.syrTop,T(p[0],p[1]));}
    const c=Math.cos(P.rot),s=Math.sin(P.rot),CM=mmul(UI.pivot,[c,s,-s,c,0,0]);
    ds(UI.chamber,CM);
    UI.slots.forEach((q,i)=>{const tf=mmul(CM,T(q[0],q[1]));if(P.slots[i]===1)ds(UI.slotReady,tf);else if(P.slots[i]===2)ds(UI.slotFired,tf);});
    ds(UI.handle,UI.handle.tf);ds(UI.nextSprite,UI.nextSprite.tf);
    const shownB=P.ammo-(P.grab&&P.grab.t==='bullet'?1:0);
    for(let i=0;i<shownB;i++)ds(UI.bulletIdle,mmul(UI.ammoTf,T(Math.floor(i/2)*50,(i%2===0)?-140:0)));
    if(P.grab&&P.grab.t==='bullet'){const d=UI.dropTf;D(0,0,0,1,1,mmul(UV,[32*d[0],0,0,32*d[3],d[4]-16*d[0],d[5]-16*d[3]]),[200,200,200,50]);}
    if(P.gun)ds(UI.equipIcon,UI.equipIcon.tf,P.out?W4:[150,150,150,200]);
    const cu=P.cur;
    if(P.grab){if(P.grab.t==='bullet')ds(UI.bulletHeld,[0.8,0,0,0.8,cu.x,cu.y]);else if(P.grab.t==='shell')ds(UI.shellHeld,[0.8,0,0,0.8,cu.x,cu.y]);
      else{const m=[0,1,-1,0,cu.x-20,cu.y+35];ds(UI.syrBase,m);ds(UI.syrTop,m);}}
    D(0,0,0,1,1,[10,0,0,10,VW/2+cu.x*VS-5,VH/2+cu.y*VS-5],P.grab?[150,110,75,255]:[230,190,150,255]);
  }
  function line2(V,x0,y0,x1,y1,th,c){const dx=x1-x0,dy=y1-y0,l=hyp(dx,dy);if(l<0.5)return;const ux=dx/l,uy=dy/l;D(0,0,0,1,1,mmul(V,[ux*l,uy*l,-uy*th,ux*th,x0+uy*th*0.5,y0-ux*th*0.5]),c);}
  const nearest=()=>{let b=1e9,r=null;for(const e of L.ent)if(e.alive&&(e.kind===2||e.kind===3)){const d=hyp(e.x-P.x,e.y-P.y);if(d<b){b=d;r=e;}}return r;};
  return {init,loadLevel,update,draw,count:()=>names.length,menu:()=>inMenu,
    dbg:()=>({x:P.x,y:P.y,hx:P.hx,hy:P.hy,hp:P.hp,drum:P.slots.filter(s=>s===1).length,held:P.ammo,gun:P.gun*2+P.out,alive:L.ent.filter(e=>e.alive&&(e.kind===2||e.kind===3)).length}),
    cheatGun:()=>{P.gun=1;P.out=1;P.slots=[1,1,1,1,1,1];},cheat:(o)=>Object.assign(P,o),inv:()=>({ammo:P.ammo,syr:P.syr,hp:P.hp,slots:P.slots.slice(),ready:P.ready,rot:P.rot,open:P.inv,grab:P.grab&&P.grab.t,cur:P.cur,bullet0:bulletPos(0),slot:[0,1,2,3,4,5].map(slotPos),syr0:syrPos(0),para:[UI.parasiteHit[4],paraY()+(UI.parasiteHit[5]-UI.parasite.tf[5])],gun:P.gun,out:P.out}),nearest,
    cheatNear:()=>{const e=nearest();if(!e)return;for(let k=0;k<16;k++){const a=k*0.3927,nx=e.x+Math.cos(a)*300,ny=e.y+Math.sin(a)*300,t={x:nx,y:ny};pushOut(t,PR);if(Math.abs(t.x-nx)<1&&Math.abs(t.y-ny)<1&&!rayBlocked(nx,ny,e.x,e.y)){P.x=nx;P.y=ny;cam.x=nx;cam.y=ny;return;}}}};
}
if(typeof module!=='undefined')module.exports=Engine;
