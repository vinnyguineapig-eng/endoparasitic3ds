import re,sys,os,struct,math,json
import numpy as np
import gd
from gd import *

SKIP_TYPES={'CanvasLayer','Control','Label','Button','Panel','TextureRect','ColorRect','VBoxContainer','HBoxContainer','ProgressBar','RichTextLabel','NinePatchRect','MarginContainer','CenterContainer','GridContainer','TextureButton','LineEdit','Light2D','Particles2D','CPUParticles2D','AudioStreamPlayer','AudioStreamPlayer2D','AnimationPlayer','Timer','Tween','Camera2D','LightOccluder2D','NavigationPolygonInstance','VisibilityEnabler2D','Polygon2D','Line2D','NavigationAgent2D','RayCast2D','Viewport','ViewportContainer','CanvasModulate','Navigation2D','Path2D','PathFollow2D','RemoteTransform2D','Position2D','YSort'}
SKIP_SUBTREE={'CanvasLayer','Control','Label','Button','Panel','TextureRect','ColorRect','VBoxContainer','HBoxContainer','ProgressBar','RichTextLabel','NinePatchRect','MarginContainer','CenterContainer','GridContainer','TextureButton','LineEdit','Viewport','ViewportContainer'}
SKIP_PREFABS=('res://effects/DropShadow.tscn','res://effects/BloodSprayer','res://effects/HitEffect')
ENTITY_RULES=[('res://player/Player.tscn','Player'),('res://misc/LevelExit.tscn','LevelExit')]
def entity_name(path):
    for p,n in ENTITY_RULES:
        if path==p:return n
    if path.startswith('res://enemies/') and path.endswith('.tscn') and 'Arm' not in path and 'Health' not in path and 'Shooter' not in path and 'Tether' not in path and 'Bar' not in path:
        return os.path.basename(path)[:-5]
    if path.startswith('res://pickups/') and os.path.basename(path) not in ('Pickup.tscn',):
        return os.path.basename(path)[:-5]
    if path.startswith('res://environment/doors/'):return os.path.basename(path)[:-5]
    return None

class TexReg:
    def __init__(s):s.ids={};s.dims=[];s.paths=[]
    def get(s,path):
        if path not in s.ids:
            s.ids[path]=len(s.paths);s.paths.append(path);s.dims.append(tex_size(path))
        return s.ids[path]
_dim={}
def tex_size(path):
    if path in _dim:return _dim[path]
    st=IMP.get(path)
    if st:
        d=read_file(st)[:12];w,_,h,_=struct.unpack('<HHHH',d[4:12])
    else:
        im=load_image(path);w,h=im.size
    _dim[path]=(w,h);return w,h

class Level:
    def __init__(s,treg):
        s.t=treg;s.tiles=[];s.sprites=[];s.cols=[];s.ents=[];s.models={};s.model_list=[]
def get_tex(ext,subs,val):
    """returns (path, regionrect or None) for a texture property value"""
    m=re.match(r'ExtResource\( ?(\d+) ?\)',val or '')
    if m:return ext[m[1]][0],None
    m=re.match(r'SubResource\( ?(\d+) ?\)',val or '')
    if m and m[1] in subs and subs[m[1]][0]=='AtlasTexture':
        pr=subs[m[1]][1];a=re.match(r'ExtResource\( ?(\d+) ?\)',pr.get('atlas',''))
        if a:return ext[a[1]][0],rect2(pr.get('region',''))
    return None,None
def sub_tileset(ext,subs,val):
    m=re.match(r'SubResource\( ?(\d+) ?\)',val or '')
    if not m:return None
    raw=subs[m[1]][1]['__raw'];T={}
    for l in raw.split('\n'):
        mm=re.match(r'(\d+)/([\w/]+) = (.*)',l)
        if mm:T.setdefault(int(mm[1]),{})[mm[2]]=mm[3]
    # shapes multiline: mark solid if "shapes = [ {"
    return T
def emit_shape(L,ext,subs,props,world,owner,model=None):
    m=re.match(r'SubResource\( ?(\d+) ?\)',props.get('shape',''))
    if not m or m[1] not in subs:return None
    typ,pr=subs[m[1]]
    if typ=='RectangleShape2D':
        hx,hy=vec2(pr.get('extents',''),(10,10));kind=0
    elif typ=='CircleShape2D':
        hx=hy=num(pr.get('radius','10'),10);kind=1
    elif typ=='CapsuleShape2D':
        r=num(pr.get('radius','10'),10);h=num(pr.get('height','20'),20);hx,hy=r,r+h/2;kind=0
    elif typ in('ConvexPolygonShape2D','ConcavePolygonShape2D'):
        nums=[float(x) for x in re.findall(r'[-\d.e+]+',pr.get('points',pr.get('segments','')).split('(',1)[-1])]
        if len(nums)<4:return None
        xs=nums[0::2];ys=nums[1::2]
        cx,cy=(min(xs)+max(xs))/2,(min(ys)+max(ys))/2;hx,hy=(max(xs)-min(xs))/2,(max(ys)-min(ys))/2;kind=0
        world=mul(world,(1,0,0,1,cx,cy))
    else:return None
    return (kind,owner,world,hx,hy)
def flatten(L,path,ctx,ovr,depth=0,model=None,state=None):
    """ctx: dict tf,z,mod,owner,static. ovr: props overriding the scene root."""
    ext,subs,nodes=parse_scene(path)
    keymap={};
    for idx,n in enumerate(nodes):
        props=dict(n['props'])
        if idx==0:props.update(ovr or {})
        if n['parent'] is None:pk=None;pc=ctx
        else:
            pk='.' if n['parent']=='.' else n['parent']
            pc=keymap.get(pk)
        if pc is None:continue          # parent skipped
        key='.' if n['parent'] is None else (n['name'] if n['parent']=='.' else n['parent']+'/'+n['name'])
        typ=n['type']
        if n['inst']:
            ipath=ext[n['inst']][0]
            if ipath.startswith(SKIP_PREFABS):continue
            if not ipath.endswith('.tscn') or ipath not in FILES:continue
        if props.get('visible','true')=='false':continue
        tf=mul(pc['tf'],local_tf(props))
        z=pc['z'];zi=int(num(props.get('z_index','0')))
        zrel=props.get('z_as_relative','true')!='false'
        z=(z+zi) if zrel else zi
        mc=color(props.get('modulate',''))
        mod=tuple(pc['mod'][i]*mc[i] for i in range(4))
        c=dict(tf=tf,z=z,mod=mod,owner=pc['owner'],static=pc['static'])
        if model=='Player' and n['name'] in('UpperArmPivot','LowerArmPivot','HandDisplay'):
            c['owner']={'UpperArmPivot':100,'LowerArmPivot':101,'HandDisplay':102}[n['name']]
            if not hasattr(L,'rig'):L.rig={}
            L.rig[c['owner']]=tf
        if typ=='StaticBody2D' or typ=='TileMap':c['static']=True
        elif typ in('Area2D','KinematicBody2D','RigidBody2D'):c['static']=False
        if typ in SKIP_SUBTREE or n['name'] in ('Lighting','CutoutLight','LightMask','Light'):continue
        keymap[key]=c
        if n['inst']:
            ipath=ext[n['inst']][0];ename=entity_name(ipath) if (model is None) else None
            if ename and depth<10:
                door=ename.endswith('Door')
                eid=len(L.ents)
                if ename not in L.models:
                    sub=Level(L.t);flatten(sub,ipath,dict(tf=(1,0,0,1,0,0),z=0,mod=(1,1,1,1),owner=-1,static=False),{},depth+1,model=ename)
                    # entity collision radius
                    rad=sub.model_rad if hasattr(sub,'model_rad') else 8.0
                    L.models[ename]=(sub,len(L.model_list));L.model_list.append(ename)
                    sub.model_rad=getattr(sub,'model_rad',rad)
                L.ents.append((ename,tf,L.models[ename][1],z,entprops(ext,ipath,props)))
                continue
            flatten(L,ipath,c,{k:v for k,v in props.items()},depth+1,model,state)
            continue
        if typ=='Sprite':
            tp,reg=get_tex(ext,subs,props.get('texture',''))
            if tp and tp!='res://icon.png' and tp in FILES|{k:1 for k in IMP}:
                tid=L.t.get(tp);W,H=L.t.dims[tid]
                hf=int(num(props.get('hframes','1'),1));vf=int(num(props.get('vframes','1'),1));fr=int(num(props.get('frame','0')))
                bx,by,bw,bh=reg if reg else (0,0,W,H)
                if props.get('region_enabled')=='true':
                    r=rect2(props.get('region_rect',''))
                    if r:bx,by,bw,bh=bx+r[0],by+r[1],r[2],r[3]
                fw,fh=bw/hf,bh/vf;sx=bx+(fr%hf)*fw;sy=by+(fr//hf)*fh
                ox,oy=vec2(props.get('offset',''))
                if props.get('centered','true')!='false':ox-=fw/2;oy-=fh/2
                sm=color(props.get('self_modulate',''))
                col=tuple(mod[i]*sm[i] for i in range(4))
                fl=(1 if props.get('flip_h')=='true' else 0)|(2 if props.get('flip_v')=='true' else 0)
                sx,sy=int(round(sx)),int(round(sy));fw,fh=int(round(fw)),int(round(fh))
                if sx<0:fw+=sx;ox-=sx if not fl&1 else 0;sx=0
                if sy<0:fh+=sy;oy-=sy if not fl&2 else 0;sy=0
                fw=min(fw,W-sx);fh=min(fh,H-sy)
                if fw<=0 or fh<=0:continue
                (model_sprites if False else L.sprites).append((tid,sx,sy,fw,fh,tf,ox,oy,col,z,fl,c['owner']))
        elif typ=='TileMap':
            ts=sub_tileset(ext,subs,props.get('tile_set',''))
            td=props.get('tile_data','')
            if ts and td:
                cw,ch=vec2(props.get('cell_size',''),(64.0,64.0))
                v=[int(x) for x in re.findall(r'-?\d+',td.split('(',1)[1])]
                for i in range(0,len(v)-2,3):
                    cell,tile,co=v[i]&0xFFFFFFFF,v[i+1]&0xFFFFFFFF,v[i+2]&0xFFFFFFFF
                    cx,cy=cell&0xFFFF,cell>>16
                    if cx>=32768:cx-=65536
                    if cy>=32768:cy-=65536
                    tid_=tile&0xFFFF;flags=(tile>>29)&7;ax,ay=co&0xFFFF,co>>16
                    T=ts.get(tid_)
                    if not T or 'texture' not in T:continue
                    tp,_=get_tex(ext,subs,T['texture'])
                    if not tp:continue
                    texid=L.t.get(tp)
                    reg=rect2(T.get('region','')) or (0,0)+L.t.dims[texid]
                    mode=int(num(T.get('tile_mode','0')))
                    if mode==1:
                        ts_=vec2(T.get('autotile/tile_size',''),(cw,ch));sp=num(T.get('autotile/spacing','0'))
                        sw,sh=ts_;sx=reg[0]+ax*(sw+sp);sy=reg[1]+ay*(sh+sp)
                    elif mode==2: # atlas
                        ts_=vec2(T.get('autotile/tile_size',''),(cw,ch));sw,sh=ts_;sx=reg[0]+ax*sw;sy=reg[1]+ay*sh
                    else:sx,sy,sw,sh=reg
                    off=vec2(T.get('tex_offset',''))
                    wx,wy=apply(tf,cx*cw+off[0],cy*ch+off[1])
                    solid=1 if ('{' in ts_raw(ext,subs,props.get('tile_set',''),tid_)) else 0
                    mc2=color(T.get('modulate',''))
                    col=tuple(mod[i]*mc2[i] for i in range(4))
                    if solid and tid_!=5: col=(col[0]*0.55,col[1]*0.58,col[2]*0.62,col[3])
                    L.tiles.append((texid,int(sx),int(sy),int(sw),int(sh),wx,wy,col,z+int(num(T.get('z_index','0'))),flags|(8 if solid else 0)))
        elif typ=='CollisionShape2D' and c['static'] and props.get('disabled')!='true':
            r=emit_shape(L,ext,subs,props,tf,c['owner'])
            if r:L.cols.append(r)
        elif typ=='CollisionShape2D' and model is not None and props.get('disabled')!='true' and not hasattr(L,'model_rad'):
            m=re.match(r'SubResource\( ?(\d+) ?\)',props.get('shape',''))
            if m and m[1] in subs:
                pr=subs[m[1]][1]
                L.model_rad=num(pr.get('radius','8'),8)*max(abs(tf[0]),abs(tf[3]))
_tsraw={}
def ts_raw(ext,subs,val,tid):
    m=re.match(r'SubResource\( ?(\d+) ?\)',val or '')
    k=(id(subs),m[1])
    if k not in _tsraw:
        raw=subs[m[1]][1]['__raw'];d={}
        for mm in re.finditer(r'^(\d+)/shapes = (.*?)(?=^\d+/|\Z)',raw,re.M|re.S):d[int(mm[1])]=mm[2]
        _tsraw[k]=d
    return _tsraw[k].get(tid,'')

def entprops(ext,ipath,props):
    _,_,nodes=parse_scene(ipath);d=dict(nodes[0]['props']);d.update(props);return d
