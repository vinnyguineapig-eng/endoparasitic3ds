import os,subprocess,re,sys,glob
from samples import *
OUT='/home/claude/port/romfs'
os.makedirs(OUT+'/sfx',exist_ok=True);os.makedirs(OUT+'/music',exist_ok=True)
NEED=['revolver_shot1','revolver_shot2','revolver_shot3','dry_fire','revolver_equip','revolver_unequip','revolver_return_bullet','grab_ground','slide_step','slide_step2',
 'pickup_revolver_bulelts','grab_thing','player_hurt','player_hurt2','hurt1','player_die','SpikrSpectralZombieAttack-001','SpikrSpectralZombieAttack-002','SpikrHurt-001','SpikrHurt-002',
 'SpikrDeath-001','SpikrDeath-002','monster_hurt','monster_die','SmallDoorOpen-001','SmallDoorClose-001','BigDoorOpen-001','click','drop_revolver_shell1']
byname={}
for p,o,s in ENTS:
    if p.endswith('.sample'):byname[p.split('/')[-1].split('.wav-')[0]]=(p,o,s)
tot=0
for n in NEED:
    if n not in byname:print('missing',n);continue
    data,pr=parse_sample(read(*byname[n]))
    ch=2 if pr['stereo'] else 1
    r=subprocess.run(['ffmpeg','-loglevel','error','-y','-f','s16le','-ar',str(pr['mix_rate']),'-ac',str(ch),'-i','-','-ac','1','-ar','16000','-af','volume=0.9','-f','s16le','-'],input=data,capture_output=True)
    open(OUT+'/sfx/%s.raw'%n.replace(' ','_'),'wb').write(r.stdout);tot+=len(r.stdout)
print('sfx bytes',tot/1e6)
TR={'labs_loop':'labs_loop','labs_track':'labs_track','maint_loop':'maint_loop','reception_track':'reception_track'}
m=0
for f in glob.glob('/home/claude/w/out/mus/*.ogg'):
    b=os.path.basename(f)
    if b.startswith('c_'):continue
    for k,v in TR.items():
        if b.startswith(k):
            r=subprocess.run(['ffmpeg','-loglevel','error','-y','-i',f,'-ac','1','-ar','16000','-f','s16le','-'],capture_output=True)
            open(OUT+'/music/%s.raw'%v,'wb').write(r.stdout);m+=len(r.stdout);print(v,len(r.stdout)/32000,'s')
print('music bytes',m/1e6)
