import re,json,sys
import gd
from gd import *
e,s,nodes=parse_scene('res://player/Player.tscn')
byk={};tfs={}
def key(n):return '.' if n['parent'] is None else (n['name'] if n['parent']=='.' else n['parent']+'/'+n['name'])
for n in nodes:
    k=key(n);byk[k]=n
    pt=tfs.get(n['parent'] if n['parent'] not in(None,) else None,(1,0,0,1,0,0)) if n['parent'] not in (None,'.') else (1,0,0,1,0,0)
    # parent key = parent path as written
    tfs[k]=mul(pt,local_tf(n['props']))
def W(path):return tfs[path]
def tex(n):
    m=re.match(r'ExtResource\( ?(\d+) ?\)',n['props'].get('texture',''));return e[m[1]][0] if m else None
def reg(n):
    r=rect2(n['props'].get('region_rect',''));return r
def info(path):
    n=byk[path];return dict(tf=W(path),tex=tex(n),region=reg(n),props={k:v[:60] for k,v in n['props'].items() if k in('position','region_rect','hframes','frame','scale','modulate','centered','offset')})
if __name__=='__main__':
    U='SpriteUILayer/UI'
    for p in [U+'/GunUI/GunReloadScreens/Revolver',U+'/GunUI/GunReloadScreens/Revolver/ChamberPivot',U+'/GunUI/GunReloadScreens/Revolver/ChamberPivot/GunChamber',U+'/GunUI/GunReloadScreens/Revolver/GunHandle',
              U+'/GunUI/GunReloadScreens/Revolver/NextRoundPos',U+'/GunUI/GunReloadScreens/Revolver/NextRoundPos/Sprite',U+'/GunUI/AmmoUI',U+'/GunUI/AmmoDropArea/BaseSprite',
              U+'/GunUI/GunEquipBar/Revolver',U+'/GunUI/GunEquipBar/Revolver/Revolver',U+'/HealthUI/HealthGraphics/Parasite',U+'/HealthUI/HealthGraphics/Parasite/Parasite',
              U+'/HealthUI/HealthGraphics/BodyGraphics/BrainBackDrop',U+'/HealthUI/HealthGraphics/BodyGraphics/Brain',U+'/HealthUI/HealthGraphics/Syringes',U+'/HealthUI/HealthGraphics/Parasite/Parasite/ParasiteBackDrop',U+'/HealthUI/HealthGraphics/Parasite/Parasite/Legs/IdleLegs']:
        if p in byk:
            i=info(p);print(p.replace(U+'/','')[-60:],[round(x,1) for x in i['tf']],i['tex'] and i['tex'].split('/')[-1],i['region'],)
        else:print('MISSING',p)
    # rig + holster (model space = Graphics space)
    for p in ['Graphics','Graphics/UpperArmPivot','Graphics/UpperArmPivot/LowerArmPivot','Graphics/UpperArmPivot/LowerArmPivot/HandBase','Graphics/BodyPivot','Graphics/BodyPivot/BodyGunDisplay/Revolver']:
        print(p[-45:],[round(x,2) for x in W(p)] if p in tfs else 'missing')
    print([ (n['name'],n['parent']) for n in nodes if n['parent'] and 'UpperArmPivot' in n['parent'] and n['type']=='Sprite'][:12])
