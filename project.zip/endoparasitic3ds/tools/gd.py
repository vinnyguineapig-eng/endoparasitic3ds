# Godot 3 scene/pck helpers for the 3DS port converter
import re,math,struct,io,pickle,os
PCK='/home/claude/w/Endoparasitic.pck'
SRC='/home/claude/w/src/'
ENTS=pickle.load(open('/home/claude/w/ents.pkl','rb'))
FILES={p:(o,s) for p,o,s in ENTS}
_pck=open(PCK,'rb')
def read_file(p):
    o,s=FILES[p];_pck.seek(o);return _pck.read(s)
# texture path -> stex path
IMP={}
for p,(o,s) in FILES.items():
    if p.endswith('.import'):
        t=read_file(p).decode('utf8','ignore');m=re.search(r'path="(res://[^"]+\.stex)"',t)
        if m:IMP[p[:-7]]=m[1]
def load_image(path):
    from PIL import Image
    st=IMP.get(path)
    if st is None and path in FILES: return Image.open(io.BytesIO(read_file(path))).convert('RGBA')
    d=read_file(st);i=d.find(b'RIFF',0,64);j=d.find(b'\x89PNG',0,64);k=i if i>=0 else j
    return Image.open(io.BytesIO(d[k:])).convert('RGBA')
_cache={}
def vec2(s,default=(0.0,0.0)):
    m=re.match(r'\s*Vector2\( ?([-\d.e+]+), ?([-\d.e+]+) ?\)',s or '')
    return (float(m[1]),float(m[2])) if m else default
def rect2(s):
    m=re.match(r'\s*Rect2\( ?([-\d.e+]+), ?([-\d.e+]+), ?([-\d.e+]+), ?([-\d.e+]+) ?\)',s or '')
    return tuple(float(x) for x in m.groups()) if m else None
def color(s,default=(1.0,1.0,1.0,1.0)):
    m=re.match(r'\s*Color\( ?([-\d.e+]+), ?([-\d.e+]+), ?([-\d.e+]+), ?([-\d.e+]+) ?\)',s or '')
    return tuple(float(x) for x in m.groups()) if m else default
def num(s,default=0.0):
    try:return float(s)
    except:return default
def parse_scene(path):
    if path in _cache:return _cache[path]
    if path not in FILES: raise KeyError(path)
    t=read_file(path).decode('utf8','ignore').replace('\r','')
    ext={};subs={};nodes=[]
    for blk in re.split(r'\n(?=\[)',t):
        m=re.match(r'\[ext_resource path="([^"]+)" type="(\w+)" id=(\d+)\]',blk)
        if m:ext[m[3]]=(m[1],m[2]);continue
        m=re.match(r'\[sub_resource type="(\w+)" id=(\d+)\]',blk)
        if m:
            props={}
            for l in blk.split('\n')[1:]:
                k,s,v=l.partition(' = ')
                if s:props[k]=v
            props['__raw']=blk
            subs[m[2]]=(m[1],props);continue
        m=re.match(r'\[node name="([^"]*)"(?: type="(\w+)")?(?: parent="([^"]*)")?(?: instance=ExtResource\( ?(\d+) ?\))?',blk)
        if m:
            props={}
            for l in blk.split('\n')[1:]:
                k,s,v=l.partition(' = ')
                if s:props[k]=v
            nodes.append(dict(name=m[1],type=m[2],parent=m[3],inst=m[4],props=props))
    _cache[path]=(ext,subs,nodes);return ext,subs,nodes
def local_tf(props):
    m=re.match(r'Transform2D\( ?([-\d.e+]+), ([-\d.e+]+), ([-\d.e+]+), ([-\d.e+]+), ([-\d.e+]+), ([-\d.e+]+) ?\)',props.get('transform',''))
    if m: return tuple(float(x) for x in m.groups())
    px,py=vec2(props.get('position',''))
    rot=num(props.get('rotation','0'))
    if 'rotation_degrees' in props: rot=math.radians(num(props['rotation_degrees']))
    sx,sy=vec2(props.get('scale',''),(1.0,1.0))
    c,s=math.cos(rot),math.sin(rot)
    return (c*sx,s*sx,-s*sy,c*sy,px,py)
def mul(p,q):
    a,b,c,d,e,f=p;A,B,C,D,E,F=q
    return (a*A+c*B,b*A+d*B,a*C+c*D,b*C+d*D,a*E+c*F+e,b*E+d*F+f)
def apply(m,x,y):
    a,b,c,d,e,f=m;return (a*x+c*y+e,b*x+d*y+f)
