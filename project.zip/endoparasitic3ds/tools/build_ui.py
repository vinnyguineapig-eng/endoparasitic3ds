# Builds romfs/ui.json: inventory screen layout (final slid-in positions) + real art regions from the original Player.tscn
import json,re,sys,math,gd
from gd import *
import uiinfo as U
e=U.e;byk=U.byk
OVR={'SpriteUILayer/UI/HealthUI':(0.0,0.0),'SpriteUILayer/UI/GunUI':(334.71,-85.985)}   # end of the original "slide_in" animation
tfs={}
for n in U.nodes:
    k=U.key(n)
    props=dict(n['props'])
    if k in OVR:props['position']='Vector2( %f, %f )'%OVR[k]
    par=n['parent'];pt=tfs.get(par,(1,0,0,1,0,0)) if par not in(None,'.') else (1,0,0,1,0,0)
    tfs[k]=mul(pt,local_tf(props))
UI='SpriteUILayer/UI/'
def clip(d,treg):
    W,H=treg.dims[d['tex']]
    if d['sx']<0:d['sw']+=d['sx'];d['ox']-=d['sx'];d['sx']=0
    if d['sy']<0:d['sh']+=d['sy'];d['oy']-=d['sy'];d['sy']=0
    d['sw']=min(d['sw'],W-d['sx']);d['sh']=min(d['sh'],H-d['sy']);return d
def sprite(path,treg):
    n=byk[path];t=U.tex(n);r=U.reg(n);tid=treg.get(t)
    W,H=treg.dims[tid];reg=r if r else (0,0,W,H)
    if n['props'].get('region_enabled')!='true' and r is None:reg=(0,0,W,H)
    hf=int(num(n['props'].get('hframes','1'),1));vf=int(num(n['props'].get('vframes','1'),1));fr=int(num(n['props'].get('frame','0')))
    fw,fh=reg[2]/hf,reg[3]/vf;sx=reg[0]+(fr%hf)*fw;sy=reg[1]+(fr//hf)*fh
    ox,oy=vec2(n['props'].get('offset',''))
    if n['props'].get('centered','true')!='false':ox-=fw/2;oy-=fh/2
    c=[1.0,1.0,1.0,1.0];parts=path.split('/')
    for i in range(1,len(parts)+1):
        nd=byk.get('/'.join(parts[:i]))
        if nd:
            m=color(nd['props'].get('modulate',''));c=[c[j]*m[j] for j in range(4)]
    sm=color(n['props'].get('self_modulate',''));c=[c[j]*sm[j] for j in range(4)]
    return clip(dict(tex=tid,sx=int(sx),sy=int(sy),sw=int(fw),sh=int(fh),ox=ox,oy=oy,tf=list(tfs[path]),c=[int(round(x*255)) for x in c]),treg)
def build(treg):
    G=UI+'GunUI/GunReloadScreens/Revolver/'
    chamber=sprite(G+'ChamberPivot/GunChamber',treg)
    slots=[]
    for n in U.nodes:
        if n['parent']==G[:-1]+'/ChamberPivot/GunChamber' and n['name'].startswith('BulletSlot'):
            px,py=vec2(n['props'].get('position',''));slots.append([px,py])
    # slot art regions (from the slot prefab)
    se,ss,sn=parse_scene('res://player/gun_ui/RevolverBulletSlot.tscn')
    def prefab_sprite(scn,name):
        ee,sss,nn=parse_scene(scn);nd=[x for x in nn if x['name']==name][0]
        m=re.match(r'ExtResource\( ?(\d+) ?\)',nd['props']['texture']);tid=treg.get(ee[m[1]][0]);r=rect2(nd['props'].get('region_rect',''))
        px,py=vec2(nd['props'].get('position',''));return clip(dict(tex=tid,sx=int(r[0]),sy=int(r[1]),sw=int(r[2]),sh=int(r[3]),ox=px-r[2]/2,oy=py-r[3]/2),treg)
    ui=dict(
      chamber=chamber,pivot=list(tfs[G+'ChamberPivot']),slots=slots,slotR=22.9761,
      slotReady=prefab_sprite('res://player/gun_ui/RevolverBulletSlot.tscn','BulletReady'),slotFired=prefab_sprite('res://player/gun_ui/RevolverBulletSlot.tscn','BulletFired'),
      handle=sprite(G+'GunHandle',treg),next=list(tfs[G+'NextRoundPos']),nextSprite=sprite(G+'NextRoundPos/Sprite',treg),
      ammoTf=list(tfs[UI+'GunUI/AmmoUI']),
      bulletIdle=prefab_sprite('res://player/gun_ui/RevolverBulletUI.tscn','IdleSprite'),bulletHeld=prefab_sprite('res://player/gun_ui/RevolverBulletUI.tscn','HeldSprite'),
      shellIdle=prefab_sprite('res://player/gun_ui/RevolverBulletUI.tscn','ShellSprite'),shellHeld=prefab_sprite('res://player/gun_ui/RevolverBulletUI.tscn','ShellHeldSprite'),
      dropTf=list(tfs[UI+'GunUI/AmmoDropArea/BaseSprite']),
      equipIcon=sprite(UI+'GunUI/GunEquipBar/Revolver/Revolver',treg),
      syrTf=list(tfs[UI+'HealthUI/HealthGraphics/Syringes']),syrTop=prefab_sprite('res://player/health_ui/Syringe.tscn','SyringeTop'),syrBase=prefab_sprite('res://player/health_ui/Syringe.tscn','SyringeBase'),
      parasite=sprite(UI+'HealthUI/HealthGraphics/Parasite/Parasite',treg),parasiteBack=sprite(UI+'HealthUI/HealthGraphics/Parasite/Parasite/ParasiteBackDrop',treg),
      legs=sprite(UI+'HealthUI/HealthGraphics/Parasite/Parasite/Legs/IdleLegs',treg),brainBack=sprite(UI+'HealthUI/HealthGraphics/BodyGraphics/BrainBackDrop',treg),brain=sprite(UI+'HealthUI/HealthGraphics/BodyGraphics/Brain',treg),
      parasiteStartY=tfs[UI+'HealthUI/HealthGraphics/ParasiteStartPos'][5],parasiteEndY=tfs[UI+'HealthUI/HealthGraphics/ParasiteEndPos'][5],
      parasiteHit=list(tfs[UI+'HealthUI/HealthGraphics/Parasite/CollisionShape2D']),holster=list(U.tfs['Graphics/BodyPivot/BodyGunDisplay/Revolver']))
    return ui

def to_txt(ui):
    """Plain-text form of the UI layout for the C engine (one item per line)."""
    out=[]
    for k in('chamber','slotReady','slotFired','handle','nextSprite','bulletIdle','bulletHeld','shellIdle','shellHeld','equipIcon','syrTop','syrBase','parasite','parasiteBack','legs','brainBack','brain'):
        s=ui[k];tf=s.get('tf',[1,0,0,1,0,0]);c=s.get('c',[255,255,255,255])
        out.append('S %s %d %d %d %d %d %.6f %.6f %s %s'%(k,s['tex'],s['sx'],s['sy'],s['sw'],s['sh'],s['ox'],s['oy'],' '.join('%.6f'%v for v in tf),' '.join(str(v) for v in c)))
    for k in('pivot','next','ammoTf','dropTf','syrTf','parasiteHit','holster'):
        out.append('M %s %s'%(k,' '.join('%.6f'%v for v in ui[k])))
    for i,(x,y) in enumerate(ui['slots']):out.append('P %d %.6f %.6f'%(i,x,y))
    for k in('slotR','parasiteStartY','parasiteEndY'):out.append('F %s %.6f'%(k,ui[k]))
    return '\n'.join(out)+'\n'
